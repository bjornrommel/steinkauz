# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
import numpy as np   # numpy library


# define Angle
class Angle():
    """
    Characterize incidence angles.

    The function input_to_angles is designed for equally spaced incidence
    angles. However, nowhere are incidence angles required to be spaced
    equally; change as you see fit.

    The single valued input_to_angle is designed for use with ttcrpy. The
    input simply maps it into the same structure as required everywhere
    else.

    Note, grad and rad are np.array([sample number x 1]).

    """
    # pylint:disable=too-few-public-methods

    # initialize
    def __init__(self):
        """
        Initialize incidence angles.

        Note, grad and rad are np.array([sample number x 1]).

        Returns
        -------
        self :
            start : float
                start of angle series
            end : float
                end of angle series
            nos : int
                number of angles
            step : float
                increment between angles
            grad : np.array
                angle(s) in grad
            rad : np.array
                angle(s) in rad

        """
        # init
        self.start = None             # first incidence angle of linear series
        self.end = None               # last incidence angle of linear series
        self.step = None              # increment of incidence angles
        self.nos = None               # sample number
        self.grad = np.array([[]])    # incidence angles in grad
        self.rad = np.array([[]])     # incidence angles in rad

    # input of a linear series of incidence angles
    def input_to_angles(self, start=None, end=None, nos=None, flag=None):
        """
        Set up equally spaced incidence angles.

        Note, grad and rad are np.array([sample number x 1]).

        Parameters
        ----------
        start : float
            start of angle series
        end : float
            end of angle series
        nos : int
            number of samples
        flag : dict 
            'print' : boolean
                print

        Returns
        -------
        self :
            start : float
                start of angle series
            end : float
                end of angle series
            nos : int
                number of angles
            step : float
                increment between angles
            grad : np.array
                angle(s) in grad
            rad : np.array
                angle(s) in rad

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # check
        check = nos >= 1
        text = f"Angles.input_to_angles: nos {nos} !> 1!"
        assert check, text
        # copy
        self.start = float(start)
        self.end = float(end)
        self.nos = int(nos)
        # set step size
        if self.nos > 1:
            # check
            check = start < end
            text = f"Angles.input_to_angles: start {start} !< end {end}!"
            assert check, text
            # step size
            self.step = (self.end - self.start) / (self.nos - 1)
        if self.nos == 1:
            check = start == end
            text = f"Angles.input_to_angles: start {start} != end {end}!"
            assert check, text
            # step size
            self.step = 0
        # generate the angle series as column vector
        self.grad = (
            np.array(
                [[self.start + self.step * iii] for iii in range(self.nos)]))
        self.rad = np.deg2rad(self.grad)
        # print
        if flag['print']:
            _ = self._printer()
        # return
        return self

    def _printer(self):
        """
        Print stiffness.

        Returns
        -------
        self : Voigt

        """
        # print
        text = "\nincidence angles:\n"
        text += (
            "\n".join([f"{item:7.3f}" for item in self.grad[:,0]]))
        print(text)
        # return
        return self
