# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
from copy import deepcopy as cp   # copy
import numpy as np                # numpy


# ttwean imports
from .velocity import Velocity
from .constant import PSIGN
from .constant import SSIGN
from .constant import WVT


class ApproxEnergyVelocity(Velocity):
    """
    Characterize a 3-term energy velocity.

    Thomsen (1986) has not provided a linear energy velocity, but a non-linear
    transformation from phase to energy angle only. In the following I provide
    a 3-term energy velocity linearized in terms of the sine of the energy
    angle.

    """

    # compute the linearized energy velocity
    def para2_to_approx_energy(
            self, para2=None, sign=None, angle=None, flag=None):
        """
        Compute a linear energy velocity.

        Note, it doesn't matter what the energy-velocity parameters are.

        Note, the incidence angles are, here, energy angles.

        Parameters
        ----------
        para2 : Generic
            phase-velocity parameters
        angle : np.array ([number x 1]) of float
            incidence angles
        sign : int, either PSIGN or SSIGN
            P-/S-wave flag
        flag : dict
            'print' : boolean
                print
            'plot' : boolean or VelocityGraphics
                show polar plot of velocity

        Returns
        -------
        energy : energyVelocity
            mag : Magnitude
                abs : np.array of floats ([nos x 1])
                    velocity magnitude over energy angle
            rad : np.array of floats ([nos x 1])
                incidence angle in rad

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # check (para2 must be computed for WVT[sign])
        check = sign == para2.sign
        text = "para2_to_approx_energy: "
        text += f"requested {WVT[sign]} != para2 {WVT[para2.sign]} sign!"
        assert check, text
        self.sign = sign
        # trig values for phase angles
        sin = np.sin(angle.rad)
        cos = np.cos(angle.rad)
        sin2 = sin ** 2
        # ### sin4 = sin2 ** 2
        # shortcuts
        sss2 = para2.sss[2,0]
        sss4 = para2.sss[4,0]
        # variable velocity factor
        # ### self.mag.abs = 1. + sss2 * sin2 + sss4 * sin4
        self.mag.abs = 1. + (sss2 + sss4 * sin2) * sin2
        # ### self.dmag.abs = 2. * (sss2 + 2. * sss4 * sin2) * sin * cos
        # reference velocity
        if self.sign == PSIGN:
            self.vp0 = para2.vp0
            self.mag.abs *= para2.vp0
        if self.sign == SSIGN:
            self.vs0 = para2.vs0
            self.mag.abs *= para2.vs0
        # incidence angles
        self.rad = cp(angle.rad)
        self.grad = cp(angle.grad)
        # number
        self.nos = angle.nos
        # components
        self.mag.xxx = self.mag.abs * sin
        self.mag.zzz = self.mag.abs * cos
        # graphics
        if flag['plot']:
            if flag['plot'].label is None:
                flag['plot'].label = f"{WVT[self.sign]} " + "linear energy"
            self.plotter(plot=flag['plot'])
        # print
        if flag['print']:
            # pylint:disable=invalid-name   # what's constant about "text"
            print("\nlinear energy angle, velocity and its components:")
            text = (
                "\n".join([
                    f"{self.grad[iii,0]:9.6f}" +
                    ", " +
                    f"{self.mag.abs[iii,0]:11.6f}" +
                    ", " +
                    f"{self.mag.xxx[iii,0]:11.6f}"
                    ", " +
                    f"{self.mag.zzz[iii,0]:11.6f}"
                    for iii in range(self.nos)]))
            print(text)
        # return
        return self
