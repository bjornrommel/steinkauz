# -*- coding: utf-8 -*-
"""
Created on Sat Jan 13 17:48:33 2024

@author: bjorn
"""

