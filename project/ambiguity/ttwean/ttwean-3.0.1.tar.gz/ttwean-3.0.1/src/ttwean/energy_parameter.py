# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
import numpy as np                # numpy


# ttwean imports
from .constant import WVT


class Para2():
    """
    Characterize energy-velocity parameters.

    v^2 = v0^2 * (1 + t2 * sin(theta)^2 + t4 * sin(theta)^4)   # squared
    v = v0 * (1 + s2 * sin(theta)^2 + s4 * sin(theta)^4)       # linear

    """
    # pylint:disable=too-few-public-methods

    # initialize
    def __init__(self):
        """
        Initialize energy-velocity parameters.

        Returns
        -------
        self :
            vp0 : float
                P reference-velocity
            vs0 : float
                S reference-velocity
            ttt : np.array ([5x1])
                squared energy-velocity parameters
            sss : np.array ([5x1])
                linear energy-velocity parameters
            rho : float
                density
            sign : int, either PSIGN or SSIGN
                wavetype
            ggg : float
                stretch factor

        """
        # init
        self.vp0 = None    # P-velocity
        self.vs0 = None    # S-velocity
        self.ttt =  (      # squared phase-velocity parameters
            np.full((5,1), fill_value=np.NAN, dtype=float))
        self.sss =  (      # linear phase-velocity parameters
            np.full((5,1), fill_value=np.NAN, dtype=float))
        self.rho = None    # density
        self.sign = None   # preserve 'P' / 'S' wave

    # convert phase-velocity parameters to energy-velocity parameters
    def para1_to_para2(self, para1=None, flag=None):
        """
        Get the squared energy-velocity parameters.

        Basically, it converts squared phase-velocity parameters into squared
        energy-velocity parameters.

        Parameters
        ----------
        para1 : Para1
            rrr : np.array ([5x1])
                squared phase-velocity parameters
        flag : dict
            'print' : boolean
                print

        Returns
        -------
        para2 : Para2
            vp0 : float
                P reference-velocity
            vs0 : float
                S reference-velocity
            ttt : np.array ([5x1])
                squared energy-velocity parameters
            sss : np.array ([5x1])
                linear energy-velocity parameters
            rho : float
                density
            sign : int, either PSIGN or SSIGN
                wavetype
            ggg : float
                stretch factor

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # copy velocities from squared phase-velocity parameters
        self.vp0 = para1.vp0
        self.vs0 = para1.vs0
        # compute squared energy-velocity parameters
        self.ttt[0,0] = 1.
        self.ttt[2,0] = para1.rrr[2,0] / (1. + para1.rrr[2,0])
        self.ttt[4,0] = (
            (para1.rrr[2,0] ** 2 * (1. + para1.rrr[2,0]) ** 2 + para1.rrr[4,0])
            /
            (1. + para1.rrr[2,0]) ** 4)
        # compute linear energy velocities
        self.sss[0,0] = 1.
        self.sss[2,0] = self.ttt[2,0] / 2.
        self.sss[4,0] = -1. * self.ttt[2,0] ** 2 / 8. + self.ttt[4,0] / 2.
        # preserve sign
        self.sign = para1.sign
        # print
        if flag['print']:
            # print squared
            text = f"\n{WVT[self.sign]} squared energy-velocity parameters:"
            text += f"\nvp0: {self.vp0:8.3f}"
            text += f"\nvs0: {self.vs0:8.3f}"
            text += f"\nt2: {self.ttt[2,0]:+2.6f}"
            text += f"\nt4: {self.ttt[4,0]:+2.6f}"
            print(text)
            # print linear
            text = f"\n{WVT[self.sign]} linear energy-velocity parameters:"
            text += f"\nvp0: {self.vp0:8.3f}"
            text += f"\nvs0: {self.vs0:8.3f}"
            text += f"\ns2: {self.sss[2,0]:+2.6f}"
            text += f"\ns4: {self.sss[4,0]:+2.6f}"
            print(text)
        # return
        return self
