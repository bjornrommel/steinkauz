# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-01-28
"""


# Python imports
import numpy as np   # numpy


# ttwean imports
from .velocity import Velocity


class ExactPhaseVelocity(Velocity):
    """
    Characterize an exact phase velocity.

    Used by voigt_to_exact_phase, thomsen_to_exact_phase, or any other exact
    phase velocity. However, applying an exact stretch on an approximate phase
    velocity is weird.

    """

    def __init__(self):
        # pylint:disable=useless-parent-delegation   # more to come!
        # inherit
        super().__init__()

    def exact_stretch(self, ggg=0.):
        """
        Stretching any phase velocity in an exact way.

        Parameters
        ----------
        ggg : float, default 0.
            stretch factor

        Returns
        -------
        vel :
            mag : np.array of floats ([nos x 1])
                stretched velocity over phase angle
            grad :
                phase angle

        """
        # copy stretch factor
        self.ggg = ggg
        # stretch magnitude
        self.mag.abs *= (
            np.sqrt(
                (1. + self.ggg)
                /
                (1. + self.ggg * np.sin(self.rad) ** 2)))
        self.dmag.abs *= (
            np.sqrt(
                (1. + self.ggg)
                /
                (1. + self.ggg * np.sin(self.rad) ** 2)))
        self.dmag.abs -= (
            (self.ggg * np.sin(self.rad) * np.cos(self.rad))
            /
            (1 + self.ggg * np.sin(self.rad) ** 2)
            *
            self.mag.abs)
        self.vp0 *= np.sqrt(1. + self.ggg)
        self.vs0 *= np.sqrt(1. + self.ggg)
        # correct later stretched phase angle
        corr1 = [
            [np.pi] if rad < -1. * np.pi / 2.
            else [0.]
            for rad in self.rad]
        corr2 = [
            [np.pi] if rad > +1. * np.pi / 2.
            else [0.]
            for rad in self.rad]
        # stretch phase angle
        self.rad = np.arctan(np.sqrt(1. + self.ggg) * np.tan(self.rad))
        # apply corrections to phase angle
        self.rad -= corr1
        self.rad += corr2
        # convert to grad
        self.grad = np.rad2deg(self.rad)
        # return
        return self

    def shorts(self, vp0=None, vs0=None, rho=None, angle=None):
        """
        Pre-compute parts of the exact phase velocity.

        See Mathematics script diff_phase.nb. The phase velocity is written in
        terms of c33, c44 (from vp0, vs0), rho, and some trigonometric
        functions. Density cancels out, though, and need not be provided.

        Parameters
        ----------
        vp0 : float
            P-velocity
        vs0 : float
            S-velocity
        rho : float
            density
        angle : Angle
            grad : np.array ([number x 1]) of float
                incidence angles in grad
            rad :
                incidence angesin rad

        Return
        ------
        qqq : list of floats [7]
            shortcuts for computing the phase velocity and its derivative

        """
        # pylint:disable=too-many-locals
        # trig functions
        cos = np.cos(angle.rad)                # cos(theta)
        cos2 = cos * cos                       # cos^2(theta)
        sin = np.sin(angle.rad)                # sin(theta)
        sin2 = sin * sin                       # sin^2(theta)
        sin3 = sin2 * sin                      # sin^3(theta)
        sin4 = sin2 * sin2                     # sin^4(theta)
        dsin2 = 4. * sin2 * cos2               # sin^2(2*theta)
        qsin = 4 * cos * sin * (cos2 - sin2)   # sin(4*theta)
        dcos = cos2 - sin2                     # cos(2*theta)
        tcos = (4 * cos2 - 3) * cos            # cos(3*theta)
        # elasticity
        c33 = vp0 ** 2 * rho
        c44 = vs0 ** 2 * rho
        # init
        self.qqq = [np.NAN] * 11   # list, not array
        # compute the parameters
        self.qqq[1] = c33 + c44
        self.qqq[2] = 2. * c33 * sin2
        self.qqq[3] = (c33 - c44) ** 2
        self.qqq[4]= -4. * c33 * (c33 - c44) * dcos * sin2
        self.qqq[5] = 4. * c33 ** 2 * sin4
        self.qqq[6] = 2. * c33 * (c33 - c44) * dsin2
        self.qqq[7] = -8 * c33 * (c33 - c44) * tcos * sin
        self.qqq[8] = 16 * c33 ** 2 * cos * sin3
        self.qqq[9] = 4 * c33 * (c33 - c44) * qsin
        self.qqq[10] = 4 * c33 * cos * sin
        # return
        return self.qqq
