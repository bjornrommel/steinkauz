# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# --- imports -----------------------------------------------------------------


# Python imports
from copy import deepcopy as cp       # copy
from functools import partial as pt   # partial  #  NOQA
import numpy as np                    # numpy


# ttwean import
from .incidence_angle import Angle  # NOQA
from .approx_phase_velocity import ApproxPhaseVelocity  # NOQA
from .approx_energy_velocity import ApproxEnergyVelocity  # NOQA
from .graphics import Axis  # NOQA
from .graphics import CartesianGraphics  # NOQA
from .exact_energy_velocity import ExactEnergyVelocity  # NOQA
from .graphics import Figure  # NOQA
from .graphics import Graphics  # NOQA
from .phase_parameter import Para1  # NOQA
from .energy_parameter import Para2  # NOQA
from .graphics import PolarGraphics  # NOQA
from .thomsen_parameter import Thomsen  # NOQA
from .thomsen_phase_velocity import ThomsenExactPhaseVelocity  # NOQA
from .traveltime_offset import TraveltimeOffset  # NOQA
from .ttwean import TTWean  # NOQA
from .traveltime_offset_graphics import TraveltimeOffsetGraphics  # NOQA
from .velocity import Velocity  # NOQA
from .velocity_graphics import VelocityGraphics  # NOQA
from .voigt_stiffness import Voigt  # NOQA
from .voigt_phase_velocity import VoigtPhaseVelocity  # NOQA


# --- user-definable constants ------------------------------------------------


# Note, change in usr.py, not here!


# print options
from .user import ANGLEPRINT          # print incidence angle  # NOQA
from .user import ELASTICITYPRINT     # print elasticity  # NOQA
from .user import THOMSENPRINT        # print Thomsen anisotropy parameter  # NOQA
from .user import PARA1PRINT          # print phase-velocity parameter  # NOQA
from .user import PARA2PRINT          # print energy-velocity parameter  # NOQA
from .user import VOIGTPHASEPRINT     # print phase velocity from elasticity  # NOQA
#from .user import THOMSENPHASEPRINT   # print phase velocity from Thomsen  # NOQA
from .user import APPROXPHASEPRINT    # print linear phase velocity  # NOQA
from .user import ENERGYPRINT         # print energy velocity  # NOQA
from .user import APPROXENERGYPRINT   # print linear energy velocity  # NOQA
from .user import TRAVELPRINT         # print traveltime-offset  # NOQA


# incidence angle of the phase
from .user import START   # first incidence angle (float)  # NOQA
from .user import NOS     # increment of incidence angles (int)  # NOQA
from .user import END     # last incidence angle (float)  # NOQA
from .user import ANGLE   # single incidence angle (float) for use with ttcrpy  # NOQA


# graphics size
from .user import PUBLICWIDTH    # big figure width of an SEG article  # NOQA
from .user import PUBLICHEIGHT   # figure height  # NOQA
from .user import FIGSIZE        # figure size  # NOQA


# "Dog Creek Shale" (Thomsen, 1986)
# (any example will do, but need some pre-defined input)
from .user import TITLE     # title  # NOQA
from .user import VP0       # reference P-velocity  # NOQA
from .user import VS0       # reference S-Velocity  # NOQA
from .user import DELTA     # Thomsen's delta  # NOQA
from .user import EPSILON   # Thomsen's epsilon  # NOQA
from .user import GAMMA     # Thomsen's gamma  # NOQA
from .user import RHO       # density  # NOQA
from .user import GGG       # stretch parameter  # NOQA


# traveltime-offset graphics
from .user import DEPTH    # interface depth  # NOQA
from .user import OFFSET   # max receiver offset  # NOQA
from .user import DXX      # receiver spacing  # NOQA


# graphics
from .user import TOOLKIT   # GUI toolkit, see usr.py for options  # NOQA
from .user import BLOCK     # show / don't block window with graphic  # NOQA


# -----------------------------------------------------------------------------


# pylint:disable=too-many-lines


# --- true constants ----------------------------------------------------------


# Do not change below!


# wavetype
from .constant import PSIGN   # +1 for a P wave  # NOQA
from .constant import SSIGN   # -1 for an SV-wave  # NOQA
from .constant import SIGN    # identifier to character  # NOQA
from .constant import WVT     # character to identifier  # NOQA


# --- incidence phase angles --------------------------------------------------
# input_to_angles   multiple equidistant angles
# input_to_angle    single angle


def input_to_angles(start=START, end=END, nos=NOS, flag=None):
    """
    Set up Angle() by giving first and last incidence angles and sample number.

    Parameters
    ----------
    start : float
        start of angle series
    end : float
        end of angle series
    nos : int
        number of angles
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    self : Angle
        incidence phase angles
        start : float
            start of angle series
        end : float
            end of angle series
        nos : int
            number of angles
        step : float
            increment between angles
        grad : np.array
            angle(s) in grad
        rad : np.array
            angle(s) in rad

    """
    # forward
    angle = (
        Angle().input_to_angles(start=start, end=end, nos=nos, flag=flag))
    # return
    return angle


def input_to_angle(angle=ANGLE, flag=None):
    """
    Set up Angle() by giving one incidence angle.

    Parameters
    ----------
    angle : float
        single angle
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    self : Angle
        incidence phase angles
        start : float
            start of angle series
        end : float
            end of angle series
        nos : int
            number of angles
        step : float
            increment between angles
        grad : np.array
            angle(s) in grad
        rad : np.array
            angle(s) in rad

    """
    # forward
    angle = (
        Angle().input_to_angles(start=angle, end=angle, nos=1, flag=flag))
    # return
    return angle


# --- stiffness in Voigt notation ---------------------------------------------
# input_to_voigt     user input
# thomsen_to_voigt   Thomsen anisotropy parameters to stiffness


def input_to_voigt(
        c11=None, c13=None, c33=None, c44=None, c66=None, rho=None, flag=None):
    """
    Set up VTI stiffness matrix in Voigt notation and density.

    Parameters
    ----------
    c11=c33, c13=c33-2*c44, c33, c44, c66=c44 : float
        elasticity parameters c11, c13, c44, c66
    rho : float
        density
    flag : dict
        'print' : boolean
            print
    Note, c33, c44 are required; otherwise, isotropy is default.

    Returns
    -------
    self : Voigt
        stiffness in Voigt notation
        ccc : np.array ([7x7])
            elasticity in Voigt's notation
        rho : float
            density
    Note, row=0 and column=0 are zeroed out so that c_ij corresponds to
    ccc[i,j].

    """
    # pylint:disable=too-many-arguments
    # forward
    voigt = (
        Voigt().input_to_voigt(
            c11=c11, c13=c13, c33=c33, c44=c44, c66=c66, rho=rho, flag=flag))
    # return
    return voigt


def thomsen_to_voigt(thomsen=None, csign=+1., flag=None):
    """
    Convert velocities + Thomsen anisotropy parameters to Voigt elasticity.

    Density defaults to 1.; so, elasticity really is elasticity x density.

    Note, strictly, c13 = +/-SQRT() - c[4,4] below, but the negative sign
    is unlikely to be the case in seismics.

    Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

    Parameters
    ----------
    thomsen : Thomsen
        Thomsen anisotropy parameters
        vp0 : float
            P-velocity
        vs0 : float
            S-velocity
        delta : float, default 0.
            Thomsen anisotropy parameter delta
        epsilon : float, default 0.
            Thomsen anisotropy parameter epsilon
        gamma : float, default 0.
            Thomsen anisotropy parameter gamma
        rho : float
            density
    csign : float, default +1, requirement +/-1
        sign occuring in conversion from delta to c13, typically +1
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    self : Voigt
        stiffness in Voigt notation
        ccc : np.array ([7x7])
            elasticity in Voigt's notation
        rho : float
            density
    Note, row=0 and column=0 are zeroed out so that c_ij corresponds to
    ccc[i,j].

    """
    # copy
    thomsen = cp(thomsen)
    # forward
    voigt = Voigt().thomsen_to_voigt(thomsen=thomsen, csign=csign, flag=flag)
    # return
    return voigt


# --- Thomsen anisotropy parameter --------------------------------------------
# input_to_thomsen   user input
# para1_to_thomsen   phase-velocity parameters to Thomsen parameters
# para2_to_thomsen   energy-velocity parameters to Thomsen parameters


def input_to_thomsen(
        vp0=None, vs0=None, delta=0., epsilon=0., gamma=0., rho=None,
        flag=None):
    """
    Set up Thomsen parameters.

    Parameters
    ----------
    vp0 : float
        reference P-velocity
    vs0 : float
        reference S-velocity
    delta : float, default is 0
        Thomsen parameter delta
    epsilon : float, default is 0
        Thomsen parameter epsilon
    gamma : float, default is 0
        Thomsen parameter gamma
    rho : float
        density
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    self : Thomsen
        Thomsen anisotropy parameters
        vp0 : float
            reference P-velocity
        vs0 : float
            reference S-velocity
        delta : float
            Thomsen parameter delta
        epsilon : float
            Thomsen parameter epsilon
        gamma : float
            Thomsen parameter gamma
        rho : float
            density

    """
    # pylint:disable=too-many-arguments
    # forward
    thomsen = (
        Thomsen().input_to_thomsen(
            vp0=vp0, vs0=vs0, delta=delta, epsilon=epsilon, gamma=gamma,
            rho=rho, flag=flag))
    # return
    return thomsen


def para1_to_thomsen(para1=None, wavetype=None, flag=None):
    """
    Convert phase-velocity parameters to Thomsen's anisotropy parameters.

    Ansatz:
        v^2 = v0^2 * (1 + r2 * sin^2(theta) + r4 * sin^4(theta))
        => vp0, vs0, delta, epsilon

    Parameters
    ----------
    para1 : Para1
        phase-velocity parameters
        vp0 : float
            P reference-velocity
        vs0 : float
            S reference-velocity
        rrr : np.array ([5x1])
            squared phase-velocity coefficients
        ooo : np.array ([5x1])
            linear phase-velocity coefficients
        rho : float
            density
        sign : int, either PSIGN or SSIGN
            wavetype
        ggg : float
            stretch factor
    wavetype : char
        "P" : P-wave
        "SV" : SV-wave
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    self : Thomsen
        Thomsen anisotropy parameters
        vp0 : float
            reference P-velocity
        vs0 : float
            reference S-velocity
        delta : float
            Thomsen parameter delta
        epsilon : float
            Thomsen parameter epsilon
        rho : float
            density

    """
    # check
    check = wavetype in (WVT[PSIGN], WVT[SSIGN])
    text = "lin_para2_to_thomsen: unknown wavetype {wavetype}!"
    assert check, text
    # copy
    para1 = cp(para1)
    # forward
    thomsen = Thomsen()
    if wavetype == "P":
        thomsen = thomsen.p_para1_to_thomsen(para1=para1, flag=flag)
    if wavetype == "SV":
        thomsen = thomsen.sv_para1_to_thomsen(para1=para1, flag=flag)
    # return
    return thomsen


def para2_to_thomsen(para2=None, wavetype=None, flag=None):
    """
    Convert energy-velocity parameters to Thomsen's anisotropy parameters.

    For ttcrpy: Convert a stretched energy velocity to Thomsen's parameters.

    Parameters
    ----------
    para2 : Para2
        energy-velocity parameters
        vp0 : float
            P reference-velocity
        vs0 : float
            S reference-velocity
        ttt : np.array ([5x1])
            squared energy-velocity parameters
        sss : np.array ([5x1])
            linear energy-velocity parameters
        rho : float
            density
        sign : int, either PSIGN or SSIGN
            wavetype
        ggg : float
            stretch factor
    wavetype : char
        "P" : P-wave
        "SV" : SV-wave
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    self : Thomsen
        Thomsen anisotropy parameters
        vp0 : float
            reference P-velocity
        vs0 : float
            reference S-velocity
        delta : float
            Thomsen parameter delta
        epsilon : float
            Thomsen parameter epsilon
        rho : float
            density

    """
    # check
    check = wavetype in (WVT[PSIGN], WVT[SSIGN])
    text = "lin_para2_to_thomsen: unknown wavetype {wavetype}!"
    assert check, text
    # copy
    para2 = cp(para2)
    # convert to phase-velocity parameters
    para1 = Para1().para2_to_para1(para2=para2)
    # forward
    thomsen = Thomsen()   # init
    if wavetype == "P":
        thomsen = thomsen.p_para1_to_thomsen(para1=para1, flag=flag)
    if wavetype == "SV":
        thomsen = thomsen.sv_para1_to_thomsen(para1=para1, flag=flag)
    # return
    return thomsen


# --- phase-velocity parameters -----------------------------------------------
# input_to_para1     user input not yet implemented
# thomsen_to_para1   Thomsen anisotropy parameters to phase-velocity parameters
# para2_to_para1     energy-velocity parameters to phase-velocity parameters
# stretch_para1      stretch of phase-velocity parameters


# convert Thomsen's anisotropy parameters to phase-velocity parameters
def thomsen_to_para1(thomsen=None, wavetype=None, flag=None):
    """
    Convert Thomsen's anisotropy parameters to phase-velocity parameters.

    Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

    Parameters
    ----------
    self : Thomsen
        Thomsen anisotropy parameters
        vp0 : float
            reference P-velocity
        vs0 : float
            reference S-velocity
        delta : float
            Thomsen parameter delta
        epsilon : float
            Thomsen parameter epsilon
        rho : float
            density
    wavetype : char
        "P" : P-wave
        "SV" : SV-wave
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    para1 : Para1
        phase-velocity parameters
        vp0 : float
            P reference-velocity
        vs0 : float
            S reference-velocity
        rrr : np.array ([5x1])
            squared phase-velocity coefficients
        ooo : np.array ([5x1])
            linear phase-velocity coefficients
        rho : float
            density
        sign : int, either PSIGN or SSIGN
            wavetype
        ggg : float
            stretch factor

    """
    # check
    check = wavetype in (WVT[PSIGN], WVT[SSIGN])
    text = "thomsen_to_para1: unknown wavetype {wavetype}!"
    assert check, text
    # copy
    thomsen = cp(thomsen)
    # forward
    para1 = Para1()   # init
    if wavetype == "P":
        para1 = para1.thomsen_to_p_para1(thomsen=thomsen, flag=flag)
    if wavetype == "SV":
        para1 = para1.thomsen_to_sv_para1(thomsen=thomsen, flag=flag)
    # return
    return para1


# convert energy-velocity parameters to phase-velocity parameters
def para2_to_para1(para2=None, flag=None):
    """
    Convert energy-velocity parameters to phase-velocity parameters.

    Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

    Parameters
    ----------
    para2 : Para2
        energy-velocity parameters
        vp0 : float
            P reference-velocity
        vs0 : float
            S reference-velocity
        ttt : np.array ([5x1])
            squared energy-velocity parameters
        sss : np.array ([5x1])
            linear energy-velocity parameters
        rho : float
            density
        sign : int, either PSIGN or SSIGN
            wavetype
        ggg : float
            stretch factor
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    para1 : Para1
        phase-velocity parameters
        vp0 : float
            P reference-velocity
        vs0 : float
            S reference-velocity
        rrr : np.array ([5x1])
            squared phase-velocity coefficients
        ooo : np.array ([5x1])
            linear phase-velocity coefficients
        rho : float
            density
        sign : int, either PSIGN or SSIGN
            wavetype
        ggg : float
            stretch factor
    """
    # copy
    para2 = cp(para2)
    # forward
    para1 = Para1().para2_to_para1(para2=para2, flag=flag)
    # return
    return para1


def stretch_para1(para1=None, ggg=0., flag=None):
    """
    Apply a stretch at phase-velocity parameters.

    A stretch applied at the phase-velocity parameters is by definition
    approximative only.

    Note, the phase-velocity parameters are passed in as an argument, but also
    defines this function that overwrites its attributes.

    You are responsible for synchronizing phase- and energy-parameters!!!

    Parameters
    ----------
    para1 : Para1
        phase-velocity parameters
    ggg : float, defaults to 0 (no stretch)
        stretch factor
    flag : dict
        'print' : boolean
            print

    """
    # forward
    para1 = (
        para1.stretch_para1(ggg=ggg, flag=flag))
    # return
    return para1


# --- energy-velocity parameters ----------------------------------------------
# input_to_para2     user input not yet implemented
# input_to_thomsen_to_para2
#                    input of Thomsen' anisotropy parameters to energy-velocity
#                    parameters
# thomsen_to_para2   Thomsen's anisotropy parameters to energy-velocity
#                    parameters
# para1_to_para2     phase-velocity parameters to energy-velocity parameters


# convert anisotropy parameters to energy-velocity parameters
def input_to_thomsen_to_para2(
        vp0=None, vs0=None, delta=0., epsilon=0., gamma=0., rho=None,
        wavetype=None, ggg=0., flag=None):
    """
    Convert Thomsen's anisotropy parameters to energy-velocity parameters.

    Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

    Parameters
    ----------
    vp0 : float
        reference P-velocity
    vs0 : float
        reference S-velocity
    delta : float, default is 0.
        Thomsen parameter delta
    epsilon : float, default is 0.
        Thomsen parameter epsilon
    gamma : float, default is 0.
        Thomsen parameter gamma
    rho : float
        density
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    ggg : float, default is 0. (neutral)
        stretch factor
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    para2 : Para2
        sss : np.array ([5x1])
            linear energy-velocity parameters

    """
    # pylint:disable=too-many-arguments
    # set up Thomsen's anisotropy parameters
    thomsen = (
        input_to_thomsen(
            vp0=vp0, vs0=vs0, delta=delta, epsilon=epsilon, gamma=gamma,
            rho=rho, flag=flag))
    # convert Thomsen's anisotropy parameters to phase-velocity parameters
    para1 = (
        thomsen_to_para1(
            thomsen=thomsen, wavetype=wavetype, flag=flag))
    # stretch
    if ggg != 0.:
        para1 = (
            stretch_para1(para1=para1, ggg=ggg, flag=flag))
    # convert phase-velocity parameters to energy-velocity parameters
    para2 = (
        para1_to_para2(para1=para1, flag=flag))
    # return
    return thomsen, para1, para2


# convert anisotropy parameters to energy-velocity parameters
def thomsen_to_para2(thomsen=None, wavetype=None, ggg=0., flag=None):
    """
    Convert Thomsen's anisotropy parameters to energy-velocity parameters.

    Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

    Parameters
    ----------
    thomsen : Thomsen
        Thomsen anisotropy parameters
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    ggg : float, default is 0. (neutral)
        stretch factor
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    para2 : Para2
        sss : np.array ([5x1])
            linear energy-velocity parameters

    """
    # pylint:disable=too-many-arguments
    # convert Thomsen's anisotropy parameters to phase-velocity parameters
    para1 = (
        thomsen_to_para1(
            thomsen=thomsen, wavetype=wavetype, flag=flag))
    # stretch
    if ggg != 0.:
        para1 = (
            stretch_para1(para1=para1, ggg=ggg, flag=flag))
    # convert phase-velocity parameters to energy-velocity parameters
    para2 = (
        para1_to_para2(para1=para1, flag=flag))
    # return
    return para1, para2


# convert phase-velocity parameters to energy-velocity parameters
def para1_to_para2(para1=None, flag=None):
    """
    Get the linear and squared energy-velocity parameters.

    Basically, it converts squared phase-velocity parameters into linear
    energy-velocity parameters.

    Parameters
    ----------
    para1 : Para1
        phase-velocity parameters
        vp0 : float
            P reference-velocity
        vs0 : float
            S reference-velocity
        rrr : np.array ([5x1])
            squared phase-velocity coefficients
        ooo : np.array ([5x1])
            linear phase-velocity coefficients
        rho : float
            density
        sign : int, either PSIGN or SSIGN
            wavetype
        ggg : float
            stretch factor
    flag : dict
        'print' : boolean
            print

    Returns
    -------
    para2 : Para2
        energy-velocity parameters
        vp0 : float
            P reference-velocity
        vs0 : float
            S reference-velocity
        ttt : np.array ([5x1])
            squared energy-velocity parameters
        sss : np.array ([5x1])
            linear energy-velocity parameters
        rho : float
            density
        sign : int, either PSIGN or SSIGN
            wavetype
        ggg : float
           stretch factor

    """
    # copy
    para1 = cp(para1)
    # forward
    para2 = Para2().para1_to_para2(para1=para1, flag=flag)
    # return
    return para2


# --- exact phase velocity ----------------------------------------------------
# voigt_to_exact_phase     stiffness to exact phase velocity
# thomsen_to_exact_phase   Thomsen's anisotropy parameters to exact phase vel.
# The above two functions should, within numerics, produce the same result.


def voigt_to_exact_phase(
        voigt=None, angle=None, wavetype=None, flag=None):
    """
    Compute an exact phase velocity from the stiffness in Voigt notation.

    Parameters
    ----------
    voigt : Voigt
        ccc : np.array ([7 x 7]) of float
            elasticity in Voigt's notation
        rho : float
            density
    angle : Angle
        rad : np.array ([number x 1]) of float
            incidence angles in rad
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    flag : dict
        'print' : boolean
            print
        'plot' : boolean
            polar plot

    """
    # copy
    voigt = cp(voigt)
    angle = cp(angle)
    # forward
    phase = (
        VoigtPhaseVelocity().voigt_to_exact_phase(
            voigt=voigt, angle=angle, sign=SIGN[wavetype], flag=flag))
    # return
    return phase


def thomsen_to_exact_phase(
        thomsen=None, angle=None, wavetype=None, flag=None):
    """
    Compute the exact phase velocity from velocities / Thomsen parameters.

    Note, Thomsen parameters are used to characterize the elasticity, but
    the computation is nonetheless exact.

    Parameters
    ----------
    thomsen : Thomsen
        velocities + Thomsen's anisotropy parameters
    angle : Angle
        incidence angles
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    flag : dict
        'print' : boolean
            print
        'plot' : boolean
            polar plot

    """
    # copy
    thomsen = cp(thomsen)
    angle = cp(angle)
    # forward
    phase = (
        ThomsenExactPhaseVelocity().thomsen_to_exact_phase(
            thomsen=thomsen, angle=angle, sign=SIGN[wavetype], flag=flag))
    # return
    return phase


# --- approximate = 3-term phase velocity -------------------------------------
# para1_to_approx_phase   phase-velocity parameters to approximate phase vel.
# The phase-velocity parameters are the coefficients of a Taylor expansion of
# the exact phase velocity in terms of the incidence angle; here, they are not
# linearized in terms of the anisotropy parameters as in Thomsen's original
# paper.


# compute the linearized phase velocity
def para1_to_approx_phase(
        para1=None, wavetype=None, angle=None, flag=None):
    """
    Compute an approximate = 3-term phase velocity.

    Note, it doesn't matter what the phase-velocity parameters are.
    v = v0 (1 + o2 sin^2(theta) + o4 sin^4(theta))

    Parameters
    ----------
    para1 : Para1
        phase-velocity parameters
    angle : np.array ([number x 1]) of float
        incidence angles in rad
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    flag : dict
        'print' : boolean
            print
        'plot' : boolean or VelocityGraphics
            show polar plot of velocity

    Returns
    -------
    phase : PhaseVelocity
        mag : np.array of floats ([nos x 1])
            velocity over phase angle
        rad : np.array of floats ([nos x 1])
            incidence angle in rad

    """
    # copy
    para1 = cp(para1)
    angle = cp(angle)
    # forward
    phase = (
        ApproxPhaseVelocity().approx_phase(
            para1=para1, sign=SIGN[wavetype], angle=angle, flag=flag))
    # return
    return phase


# --- exact energy velocity ---------------------------------------------------
# phase_to_exact_energy   phase velocity to exact energy velocity
# The energy velocity is computed exactly; so, it is sensibly used only with an
# exact phase velocity to start with.


def phase_to_exact_energy(phase=None, flag=None):
    """
    Compute energy velocity from a phase velocity via Berryman.

    w(phi) =
        Sqrt[
            v(theta)^2 + dv(theta)^2]
    tan(phi) =
        (tan(theta) + dv(theta)/v(theta))
        /
        (1 - tan(theta) * dv(theta)/v(theta))

    Parameters
    ----------
    phase : PhaseVelocity
        phase velocity
    flag : dict
        'print' : boolean
            print
        'plot' : boolean or VelocityGraphics
            plot

    """
    # copy
    phase = cp(phase)
    # forward
    energy = (
        ExactEnergyVelocity().exact_energy(
            phase=phase, flag=flag))
    # return
    return energy


# --- approximate energy velocity ---------------------------------------------
# para2_to_approx_energy   energy-velocity parameters to energy velocity


# compute the linearized energy velocity
def para2_to_approx_energy(
        para2=None, wavetype=None, angle=None, flag=None):
    """
    Compute a linear energy velocity.

    Note, it doesn't matter what the energy-velocity parameters are.

    Note, the incidence angles are, here, energy angles.

    Parameters
    ----------
    para2 : Generic
        phase-velocity parameters
    angle : np.array ([number x 1]) of float
        incidence angles
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    flag : dict
        'print' : boolean
            print
        'plot' : boolean or VelocityGraphics
            show polar plot of velocity

    Returns
    -------
    energy : energyVelocity
        mag : np.array of floats ([nos x 1])
            velocity over energy angle
        rad : np.array of floats ([nos x 1])
            incidence angle in rad

    """
    # copy
    para2 = cp(para2)
    angle = cp(angle)
    # forward
    energy = (
        ApproxEnergyVelocity().para2_to_approx_energy(
            para2=para2, sign=SIGN[wavetype], angle=angle, flag=flag))
    # return
    return energy


# --- traveltime-offset -------------------------------------------------------
# traveltime_offset   traveltime over offset from any energy velocity


def traveltime_offset(
        energy=None, depth=None, offset=None, flag=None, ref=None):
    """
    Compute traveltime with a virtual source at depth.

    Parameters
    ----------
    energy : EnergyVelocity
        energy velocity
    depth : float
        depth of reflector
    offset : float
        max offset
    flag : dict
        'print' : boolean
            print
        'plot' : boolean or TraveltimeOffsetGraphics
            plot traveltime-offset
    ref : None or TravelOffset
        traveltime to substract

    """
    # pylint:disable=too-many-arguments
    # copy
    energy = cp(energy)
    # forward
    tplot = (
        TraveltimeOffset().traveltime_offset(
            energy=energy, depth=depth, offset=offset, flag=flag, ref=ref))
    # return
    return tplot


# --- ttcrpy ------------------------------------------------------------------
# ttinit   initialize energy-velocity parameters per medium/wavetype/stretch
# ttvel    compute the energy velocity


def ttinit(
        vp0:float=VP0, vs0:float=VS0, delta:float=DELTA, epsilon:float=EPSILON,
        wavetype:str="P", ggg:float=0.) -> np.array:
    """
    Precompute the linear energy-velocity parameters once.

    ttinit must be run for each medium, wavetype, and/or stretch once. It is
    the user's responsibility to assign the correct output to each cell. See
    Giroux's Jupyter notebook for details.
    ttvel must be run for each incidence angle, and it would be valid, albeit
    impractical, for all cells of the same medium and for the same wavetype
    and stretch. Typically, though, it would be run for each cell for each time
    step.

    Typically,
        vp0[medium,stretch], vs0[medium,stretch],
        sss[medium,stretch,wavetype] = (
            ttinit(
                vp0=VP0, vs0=VS0, delta=DELTA, epsilon=EPSILON,
                wavetype="P" or wavetype="SV", ggg=GGG))
        vel[wavetype,angle,cell] = (
            ttvel(
                vp0=vp0[medium,stretch], vs0=vs0[medium,stretch],
                sss=sss[medium,stretch], wavetype=wavetype, angle=ANGLE)
    Note, all capital for user-defined parameters.
    Any stretch modifies P and SV-velocities: so, be careful not to overwrite
    your in- and output variable.
    Use the same wavetype for ttinit and ttray.

    Parameters
    ----------
    vp0 : float
        reference P-velocity
    vs0 : float
        reference S-velocity
    delta : float, default is 0.
        Thomsen parameter delta
    epsilon : float, default is 0.
        Thomsen parameter epsilon
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    ggg : float, default is 0. (neutral)
        stretch factor

    Returns
    -------
    vp0, vs0 : float
        P- and SV-reference velocities: modified only if stretched
    sss : np.array ([5x1])
        linear energy-velocity parameters

    """
    # pylint:disable=too-many-arguments
    # forward
    vp0, vs0, sss = (
        TTWean().ttinit(
            vp0=vp0, vs0=vs0, delta=delta, epsilon=epsilon,
            wavetype=wavetype, ggg=ggg))
    # return
    return vp0, vs0, sss


def ttvel(
        vp0:float=None, vs0:float=None, sss:np.array=None, wavetype:str=None,
        angle:float=None) -> float:
    """
    Compute a linear energy velocity for a given directional angle.

    ttinit must be run for each medium, wavetype, and/or stretch once. It is
    the user's responsibility to assign the correct output to each cell. See
    Giroux's Jupyter notebook for details.
    ttvel must be run for each incidence angle, and it would be valid, albeit
    impractical, for all cells of the same medium and for the same wavetype
    and stretch. Typically, though, it would be run for each cell for each time
    step.

    Typically,
        vp0[medium,stretch], vs0[medium,stretch],
        sss[medium,stretch,wavetype] = (
            ttinit(
                vp0=VP0, vs0=VS0, delta=DELTA, epsilon=EPSILON,
                wavetype="P" or wavetype="SV", ggg=GGG))
        vel[wavetype,angle,cell] = (
            ttvel(
                vp0=vp0[medium,stretch], vs0=vs0[medium,stretch],
                sss=sss[medium,stretch], wavetype=wavetype, angle=ANGLE)
    Note, all capital for user-defined parameters.
    Any stretch modifies P and SV-velocities: so, be careful not to overwrite
    your in- and output variable.
    Use the same wavetype for ttinit and ttray.

    Parameters
    ----------
    vp0 : float
        reference P-velocity
    vs0 : float
        reference S-velocity
    sss : np.array ([5x1])
        linear energy-velocity parameters
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    angle : float
        incidence angle in radiant

    Returns
    -------
    vel : float
        magnitude of an energy velocity for the given incidence angle/wavetype

    """
    # copy
    sss = cp(sss)
    # forward
    vel = (
        TTWean().ttvel(
            vp0=vp0, vs0=vs0, sss=sss, wavetype=wavetype, angle=angle))
    # return
    return vel
