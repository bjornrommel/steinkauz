# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
from copy import deepcopy as cp   # copy
import numpy as np                # numpy


# ttwean imports
from .exact_phase_velocity import ExactPhaseVelocity
from .constant import PSIGN
from .constant import SSIGN
from .constant import WVT


class ThomsenExactPhaseVelocity(ExactPhaseVelocity):
    """
    Characterize a phase velocity from Thomsen's anisotropy parameters.

    """

    # initialize
    def __init__(self):
        """
        Initialize a phase velocity.

        """
        # pylint:disable=useless-parent-delegation
        # inherit
        super().__init__()

    def thomsen_to_exact_phase(
            self, thomsen=None, angle=None, sign=None, flag=None):
        """
        Compute the exact phase velocity from velocities / Thomsen parameters.

        Note, Thomsen parameters are used to characterize the elasticity, but
        the computation is nonetheless exact.

        Parameters
        ----------
        thomsen : Thomsen
            velocities + Thomsen's anisotropy parameters
        angle : Angle
            incidence angles
        sign : int
            P=+1., S=-1.
            sign used in phase velocity
        flag : dict 
            'print' : boolean
                print
            'plot' : boolean
                polar plot

        """
        # pylint:disable=invalid-name
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # assign angle
        self.grad = cp(angle.grad)
        self.rad = cp(angle.rad)
        # assign sign
        check = sign in (PSIGN, SSIGN)
        text = f"thomsen_to_exact_phase: unknown wavetype {WVT[sign]}!"
        assert check, text
        self.sign = cp(sign)
        # shorts (in ExactPhaseVelocity)
        self.qqq = (
            self.shorts(
                vp0=thomsen.vp0, vs0=thomsen.vs0, rho=thomsen.rho,
                angle=angle))
        # see Mathematics derivative.nb
        p3 = self.qqq[1] + self.qqq[2] * thomsen.epsilon
        p12 = (
            self.qqq[3] +
            self.qqq[4] * thomsen.epsilon +
            self.qqq[5] * thomsen.epsilon ** 2 +
            self.qqq[6] * thomsen.delta)
        dp12t = (
            self.qqq[7] * thomsen.epsilon +
            self.qqq[8] * thomsen.epsilon ** 2 +
            self.qqq[9] * thomsen.delta)
        dp3t = self.qqq[10] * thomsen.epsilon
        self.mag.abs = p3 + self.sign * np.sqrt(p12)
        self.mag.abs = np.sqrt(self.mag.abs / (2. *thomsen.rho))
        self.dmag.abs = (
            ((self.sign * dp12t) / (2 * np.sqrt(p12)) + dp3t)
            /
            (4 * thomsen.rho * self.mag.abs))
        # number
        self.nos = angle.nos
        # reference velocities
        self.vp0 = thomsen.vp0
        self.vs0 = thomsen.vs0
        # plot
        if flag['plot']:
            if flag['plot'].label is None:
                flag['plot'].label = WVT[self.sign] + "exact phase (Thomsen)"
            self.plotter(plot=flag['plot'])
        # print
        if flag['print']:
            _ = self.printer()
        # return
        return self

    def printer(self):
        """
        Print phase-velocity.

        Returns
        -------
        self : VoigtPhaseVelocity

        """
        text = "\n" + WVT[self.sign]
        text += " exact phase velocity from Thomsen:\n"
        text += "\n".join([f"{item:7.3f}" for item in self.mag.abs[:,0]])
        print(text)
        # return
        return self
