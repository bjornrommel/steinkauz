# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
from copy import deepcopy as cp   # copy
import numpy as np                # numpy


# ttwean imports
from .velocity import Velocity
from .constant import PSIGN
from .constant import SSIGN
from .constant import WVT


class ApproxPhaseVelocity(Velocity):
    """
    Characterize an approximate = 3-term phase velocity.

    """

    # compute the linearized phase velocity
    def approx_phase(
            self, para1=None, sign=None, angle=None, flag=None):
        """
        Compute an approximate = 3-term phase velocity.

        Note, it doesn't matter what the phase-velocity parameters are.
        v = v0 (1 + o2 sin^2(theta) + o4 sin^4(theta))

        Parameters
        ----------
        para1 : Para1
            phase-velocity parameters
        angle : np.array ([number x 1]) of float
            incidence angles in rad
        sign : int, either PSIGN or SSIGN
            P-/S-wave flag
        flag : dict
            'print' : boolean
                print
            'plot' : boolean or VelocityGraphics
                show polar plot of velocity

        Returns
        -------
        phase : PhaseVelocity
            mag : Magnitude
                abs : np.array of floats ([nos x 1])
                    velocity magnitude over energy angle
            rad : np.array of floats ([nos x 1])
                incidence angle in rad

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # check with variable para1
        check = sign == para1.sign
        text = "approx_phase: "
        text += f"requested {sign:1d} != approx {para1.sign:1d} sign"
        assert check, text
        self.sign = sign
        # copy angle
        self.grad = cp(angle.grad)
        self.rad = cp(angle.rad)
        # trig values
        sin = np.sin(self.rad)
        cos = np.cos(self.rad)
        sin2 = sin ** 2
        sin4 = sin2 ** 2
        # variable velocity factor
        self.mag.abs = (
            (1. + para1.ooo[2,0] * sin2 + para1.ooo[4,0] * sin4))
        self.dmag.abs = 2 * (para1.ooo[2,0] + 2 * para1.ooo[4,0]) * sin * cos
        # reference velocity
        if self.sign == SSIGN:
            self.vs0 = para1.vs0
            self.mag.abs *= para1.vs0
        if self.sign == PSIGN:
            self.vp0 = para1.vp0
            self.mag.abs *= para1.vp0
        # number
        self.nos = angle.nos
        # graphics
        if flag['plot']:
            if flag['plot'].label is None:
                flag['plot'].label = f"{WVT[self.sign]} " + "linear phase"
            self.plotter(plot=flag['plot'])
        # print
        if flag['print']:
            text = "\n" + WVT[para1.sign] + " linear phase velocity:\n"
            text += "\n".join([f"{item:7.3f}" for item in self.mag.abs[:,0]])
            print(text)
        # return
        return self
