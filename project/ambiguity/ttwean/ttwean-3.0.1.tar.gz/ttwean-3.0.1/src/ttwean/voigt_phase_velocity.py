# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
from copy import deepcopy as cp   # copy
import numpy as np                # numpy


# ttwean imports
from .exact_phase_velocity import ExactPhaseVelocity
from .constant import PSIGN
from .constant import SSIGN
from .constant import WVT


class VoigtPhaseVelocity(ExactPhaseVelocity):
    """
    Characterize a phase velocity from the stiffness in Voigt notation.

    """

    # initialize
    def __init__(self):
        """
        Initialize a phase velocity from the stiffness in Voigt notaton.

        """
        # inherit
        super().__init__()
        # init
        self.sign = None   # P-/S-wave flag
        self.qqq = None    # some shortcuts

    # compute the exact phase velocity
    def voigt_to_exact_phase(
            self, voigt=None, angle=None, sign=None, flag=None):
        """
        Compute an exact phase velocity from the stiffness in Voigt notation.
        
        See Mathematica script phasevelocity.

        Parameters
        ----------
        voigt : Voigt
            ccc : np.array ([7 x 7]) of float
                elasticity in Voigt's notation
            rho : float
                density
        angle : Angle
            grad : np.array ([number x 1]) of float
                incidence angles in grad = copy from angle.grad
            rad : np.array ([number x 1]) of float
                incidence angles in rad
        sign : int, either PSIGN or SSIGN
            PSIGN : P-wave
            SSIGN : S-wave
        flag : dict 
            'print' : boolean
                print
            'plot' : boolean
                polar plot
            
        Returns
        -------
        self : VoigtPhaseVelocity
            mag : Velocity
                abs : magnitude of phase velocity
            dmag : Velocity
                abs : magnitude of differential phase velocity
            grad : np.array ([number x 1]) of float
                incidence angles in grad = copy from angle.grad
            rad : np.array ([number x 1]) of float
                incidence angles in rad = copy from angle.rad
            sign : int, either PSIGN or SSIGN
                PSIGN : P-wave
                SSIGN : S-wave
            ...

        """
        # pylint:disable=too-many-locals  # following Mathematica script
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # check sign
        check = sign in (PSIGN, SSIGN)
        text = (
            "VoigtPhaseVelocity.voigt_exact_phase:" +
            f" unknown wavetype {WVT[sign]}!")
        assert check, text
        self.sign = sign
        # shortcut trigs
        sin = np.sin(angle.rad)
        cos = np.cos(angle.rad)
        sin2 = sin * sin
        cos2 = cos * cos
        dcos = cos2 - sin2
        dsin = 2 * sin * cos
        dsin2 = dsin * dsin
        # shortcut elasticity
        c11 = voigt.ccc[1,1]
        c13 = voigt.ccc[1,3]
        c33 = voigt.ccc[3,3]
        c44 = voigt.ccc[4,4]
        rho = voigt.rho
        # compute the magnitude of the phase velocity
        # (notation follows Mathematica script)
        ppp12 = (
            ((c11 - c44) * sin2 - (c33 - c44) * cos2) ** 2
            +
            (c13 + c44) ** 2 * dsin2)
        ppp3 = c11 * sin2 + c33 * cos2 + c44
        self.mag.abs = (
            np.sqrt(
                (ppp3 + self.sign * np.sqrt(ppp12))
                /
                (2. * rho)))
        dppp12 = (
            (c11 + c33 - 2 * c44) *
            (c11 - c33 - (c11 + c33 - 2* c44) * dcos) *
            dsin
            +
            4 * (c13 + c44) ** 2 * dsin * dcos)
        dppp3 = (c11 - c33) * dsin
        self.dmag.abs = (
            ((self.sign * dppp12) / (2 * np.sqrt(ppp12)) + dppp3)
            /
            (4 * rho * self.mag.abs))
        # copy reference velocities
        self.vp0 = np.sqrt(c33 / rho)
        self.vs0 = np.sqrt(c44 / rho)
        # copy incidence angle
        self.grad = cp(angle.grad)
        self.rad = cp(angle.rad)
        # compute the magnitude components
        self.mag.xxx = self.mag.abs * np.sin(self.rad)
        self.mag.zzz = self.mag.abs * np.cos(self.rad)
        # number
        self.nos = angle.nos
        # plot
        if flag['plot']:
            if flag['plot'].label is None:
                flag['plot'].label = WVT[self.sign] + "exact phase (Voigt)"
            self.plotter(plot=flag['plot'])
        # print
        if flag['print']:
            _ = self._printer()
        # return
        return self

    def _printer(self):
        """
        Print phase-velocity.

        Returns
        -------
        self : VoigtPhaseVelocity

        """
        # print
        text = "\n" + WVT[self.sign]
        text += " exact phase velocity from elasticity:\n"
        text += "\n".join([f"{item:7.3f}" for item in self.mag.abs[:,0]])
        print(text)
        # return
        return self
