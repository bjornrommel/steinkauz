# -*- coding: utf-8 -*-
"""
Created on Sun Jan 14 15:52:37 2024

@author: bjorn
""""""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
import numpy as np   # numpy


# ttwean imports
from .constant import PSIGN
from .constant import SSIGN
from .constant import WVT


class Para1():
    """
    Characterize phase-velocity parameters.

    v^2 = v0^2 * (1 + r2 * sin(theta)^2 + r4 * sin(theta)^4)   # squared
    v = v0 * (1 + o2 * sin(theta)^2 + o4 * sin(theta)^4)       # linear

    """

    # initialize
    def __init__(self):
        """
        Initialize phase-velocity parameters.

        Returns
        -------
        self :
            vp0 : float
                P reference-velocity
            vs0 : float
                S reference-velocity
            rrr : np.array ([5x1])
                squared phase-velocity coefficients
            ooo : np.array ([5x1])
                linear phase-velocity coefficients
            rho : float
                density
            sign : int, either PSIGN or SSIGN
                wavetype
            ggg : float
                stretch factor

        """
        # init
        self.vp0 = None    # P-velocity
        self.vs0 = None    # S-velocity
        self.rrr =  (      # squared phase-velocity parameters
            np.full((5,1), fill_value=np.NAN, dtype=float))
        self.ooo =  (      # linear phase-velocity parameters
            np.full((5,1), fill_value=np.NAN, dtype=float))
        self.rho = None    # density
        self.sign = None   # preserve 'P' / 'S' wave
        self.ggg = None    # stretch factor

    # convert Thomsen's anisotropy parameters for a P-wave
    def thomsen_to_p_para1(self, thomsen=None, flag=None):
        """
        Convert Thomsen's anisotropy parameters to P phase-velocity ones.

        Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

        Parameters
        ----------
        thomsen : Thomsen
            Thomsen's anisotropy parameters
        flag : dict 
            'print' : boolean
                print

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # copy velocity from thomsen
        self.vp0 = thomsen.vp0
        self.vs0 = thomsen.vs0
        # compute squared phase-velocity parameters
        vps2 = (self.vp0 / self.vs0) ** 2
        fac = 1. + 2. * vps2 / (vps2 - 1.) * thomsen.delta
        self.rrr[0,0] = 1.
        self.rrr[2,0] = 2. * thomsen.delta
        self.rrr[4,0] = 2. * (thomsen.epsilon - thomsen.delta) * fac
        # convert to linear phase-velocity parameters
        _ = self._sqr_to_lin()
        # sign
        self.sign = PSIGN
        # print
        if flag:
            _ = self._printer()
        # return
        return self

    # convert Thomsen's anisotropy parameters for an SV-wave
    def thomsen_to_sv_para1(self, thomsen=None, flag=None):
        """
        Convert Thomsen's anisotropy parameters to SV phase-velocity ones.

        Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

        Parameters
        ----------
        thomsen : Thomsen
            Thomsen's anisotropy parameters
        flag : dict 
            'print' : boolean
                print

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # copy velocity from thomsen
        self.vp0 = thomsen.vp0
        self.vs0 = thomsen.vs0
        # compute the theoretical phase-velocity parameters
        vps2 = (self.vp0 / self.vs0) ** 2
        fac = 1. + 2. * vps2 / (vps2 - 1.) * thomsen.delta
        self.rrr[0,0] = 1.
        self.rrr[2,0] = 2. * vps2 * (thomsen.epsilon - thomsen.delta)
        self.rrr[4,0] = -1. * self.rrr[2,0] * fac
        # convert to linear phase-velocity parameters
        _ = self._sqr_to_lin()
        # sign
        self.sign = SSIGN
        # print
        if flag['print']:
            _ = self._printer()
        # return
        return self

    # convert linear energy-velocity parameters to phase-velocity ones.
    def para2_to_para1(self, para2=None, flag=None):
        """
        Convert linear energy-velocity parameters to phase-velocity ones.

        From energy velocity
        w^2 = w0^2 * (1 + s2 * sin(theta)^2 + s4 * sin(theta)^4)

        Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

        Parameters
        ----------
        para2 : Para2
            energy-velocity parameters
        flag : dict 
            'print' : boolean
                print

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # copy velocity from thomsen
        self.vp0 = para2.vp0
        self.vs0 = para2.vs0
        # compute squared phase-velocity parameters
        self.rrr[0,0] = 1.
        self.rrr[2,0] = 2. * para2.sss[2,0] / (1. - 2. * para2.sss[2,0])
        self.rrr[4,0] = 8. * (1. + self.rrr[2,0]) ** 4 * para2.sss[4,0]
        self.rrr[4,0] -= 3 * self.rrr[2,0] ** 2 * (1 + self.rrr[2,0]) ** 2
        self.rrr[4,0] /= 4.
        # convert to linear phase-velocity parameters
        _ = self._sqr_to_lin()
        # sign
        self.sign = para2.sign
        # print
        if flag['print']:
            _ = self._printer()
        # return
        return self

    # stretch
    def stretch_para1(self, ggg=None, flag=None):
        """
        Apply a stretch at phase-velocity parameters.

        A stretch applied at the phase-velocity parameters is by definition
        approximative only.

        Parameters
        ----------
        ggg : float
            stretch factor
        flag : dict 
            'print' : boolean
                print

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # check strech factor
        check = ggg is not None
        text = "Para1.stretch_para1: stretch factor unspecified!"
        assert check, text
        check = ggg > -1.
        text = "Para1.stretch_para1: stretch {ggg} !> -1!"
        assert check, text
        # copy
        self.ggg = ggg
        # stretch reference velocity
        self.vp0 *= np.sqrt(1. + self.ggg)
        self.vs0 *= np.sqrt(1. + self.ggg)
        # stretch squared phase-velocity parameters
        self.rrr[1,0] = 1.
        self.rrr[2,0] = (self.rrr[2,0] - self.ggg) / (1. + self.ggg)
        self.rrr[4,0] = self.rrr[4,0] / ((1. + self.ggg) ** 2)
        # convert to linear phase-velocity parameters
        _ = self._sqr_to_lin()
        # print
        print(f"\nstretch factor:\ng: {self.ggg:+2.6f}")
        if flag['print']:
            self._printer()
        # return
        return self

    def _sqr_to_lin(self):
        """
        Convert squared phase-velocity coefficients to linear ones.

        v^2 = v0^2 * (1 + r2 * sin(theta)^2 + r4 * sin(theta)^4)
        v = v0 * (1 + o2 * sin(theta)^2 + o4 * sin(theta)^4)

        Returns
        -------
        self : Para1

        """
        # compute linear phase-velocity parameters from squared ones
        self.ooo[0,0] = 1.
        self.ooo[2,0] = self.rrr[2,0] / 2.
        self.ooo[4,0] = -1. * self.rrr[2,0] ** 2 / 8. + self.rrr[4,0] / 2.
        # return (completes self.ooo)
        return self

    def _printer(self):
        """
        Print phase-velocity parameters.

        Returns
        -------
        self : Para1

        """
        text = f"\n{WVT[self.sign]} squared phase-velocity parameters:"
        if self.ggg is not None:
            text += f"\ng: {self.ggg:+2.6f}"
        text += f"\nvp0: {self.vp0:8.3f}"
        text += f"\nvs0: {self.vs0:8.3f}"
        text += f"\nr2: {self.rrr[2,0]:+2.6f}"
        text += f"\nr4: {self.rrr[4,0]:+2.6f}"
        print(text)
        text = f"\n{WVT[self.sign]} linear phase-velocity parameters:"
        if self.ggg is not None:
            text += f"\ng: {self.ggg:+2.6f}"
        text += f"\nvp0: {self.vp0:8.3f}"
        text += f"\nvs0: {self.vs0:8.3f}"
        text += f"\no2: {self.ooo[2,0]:+2.6f}"
        text += f"\no4: {self.ooo[4,0]:+2.6f}"
        print(text)
        # return
        return self
