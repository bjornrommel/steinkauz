# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-01-28
"""


# Python imports
import sys                        # system
import warnings as wn             # warnings
from copy import deepcopy as cp   # copy
import numpy as np                # numpy


# ttwean import
from .voigt_stiffness import Voigt


# define Thomsen, a class for handling Thomsen anisotrop parameters
class Thomsen():
    """
    Characterize Thomsen parameters.

    vp0 : reference P-velocity
    vs0 : reference S-velocity
    delta : Thomsen parameter delta
    epsilon : Thomsen parameter epsilon
    gamma : Thomsen parameter gamma
    rho : density

    """

    # initialize
    def __init__(self):
        """
        Initialize Thomsen's anisotropy parameters.

        Returns
        -------
        self :
            vp0 : float
                reference P-velocity
            vs0 : float
                reference S-velocity
            delta : float
                Thomsen parameter delta
            epsilon : float
                Thomsen parameter epsilon
            gamma : float
                Thomsen parameter gamma
            rho : float
                density
        """
        # init
        self.vp0 = None       # P-reference velocity
        self.vs0 = None       # S-reference velocity
        self.delta = None     # anisotropy parameter delta
        self.epsilon = None   # anisotropy parameter epsilon
        self.gamma = None     # anisotropy parameter gamma
        self.rho = None       # density

    def input_to_thomsen(
            self, vp0=None, vs0=None, delta=None, epsilon=None, gamma=None,
            rho=None, flag=None):
        """
        Set up Thomsen parameters.

        Parameters
        ----------
        vp0 : float
            reference P-velocity
        vs0 : float
            reference S-velocity
        delta : float, default is 0
            Thomsen parameter delta
        epsilon : float, default is 0
            Thomsen parameter epsilon
        gamma : float, default is 0
            Thomsen parameter gamma
        rho : float
            density
        flag : dict 
            'print' : boolean
                print

        Returns
        -------
        self :
            vp0 : float
                reference P-velocity
            vs0 : float
                reference S-velocity
            delta : float
                Thomsen parameter delta
            epsilon : float
                Thomsen parameter epsilon
            gamma : float
                Thomsen parameter gamma
            rho : float
                density

        """
        # pylint:disable=too-many-arguments
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # default to isotropy if None
        if delta is None:
            delta = 0.
        if epsilon is None:
            epsilon = 0.
        if gamma is None:
            gamma = 0.
        # check density
        check = rho > 0.
        text = f"input_to_thomsen: density {rho} !> 0.!"
        assert check, text
        # copy
        self.vp0 = vp0           # P-velocity
        self.vs0 = vs0           # S-velocity
        self.delta = delta       # delta
        self.epsilon = epsilon   # Thomsen epsilon
        self.gamma = gamma       # Thomsen gamma
        self.rho = rho           # density
        # check stability
        _ = Voigt().thomsen_to_voigt(thomsen=cp(self), flag=cp(None))
        # print
        if flag['print']:
            _ = self._printer()
        # return
        return self

    def p_para1_to_thomsen(self, para1=None, flag=None):
        """
        Convert P phase-velocity parameters to Thomsen's anisotropy ones.
        
        v^2 = v0^2 * (1 + r2 * sin^2(theta) + r4 * sin^4(theta))

        Parameters
        ----------
        para1 : Para1
            phase-velocity parameters for a P-wave
        flag : dict 
            'print' : boolean
                print

        Returns
        -------
        self :
            vp0 : float
                reference P-velocity
            vs0 : float
                reference S-velocity
            delta : float
                Thomsen parameter delta
            epsilon : float
                Thomsen parameter epsilon
            rho : float
                density

        """
        # copy velocities
        self.vp0 = para1.vp0
        self.vs0 = para1.vs0
        # convert to Thomsen's anisotropy parameters
        fak = self.vp0 ** 2 / (self.vp0 ** 2 - self.vs0 ** 2)
        self.delta = para1.rrr[2,0] / 2.
        self.epsilon = (
            para1.rrr[4,0] / (1. + 2. * fak * self.delta) / 2. + self.delta)
        # default other parameters
        self.gamma = 0.   # no information
        # density
        self.rho = para1.rho
        # check stability
        _ = Voigt().thomsen_to_voigt(thomsen=cp(self), flag=None)
        # print
        if flag:
            self._printer()
        # return
        return self

    def sv_para1_to_thomsen(self, para1=None, flag=None):
        """
        Convert SV phase-velocity parameters to Thomsen's anisotropy ones.

        v^2 = v0^2 * (1 + r2 * sin^2(theta) + r4 * sin^4(theta))
        
        Parameters
        ----------
        para1 : Para1
            phase-velocity parameters for a P-wave
        flag : boolean
            print

        Returns
        -------
        self :
            vp0 : float
                reference P-velocity
            vs0 : float
                reference S-velocity
            delta : float
                Thomsen parameter delta
            epsilon : float
                Thomsen parameter epsilon
            rho : float
                density

        """
        # copy velocities
        self.vp0 = para1.vp0
        self.vs0 = para1.vs0
        # convert to Thomsen's anisotropy parameters
        fak = self.vp0 ** 2 / (self.vp0 ** 2 - self.vs0 ** 2)
        rat = (self.vp0 / self.vs0) ** 2
        with np.errstate(all = 'raise'):     # numpy warnings
            with wn.catch_warnings():        # other warnings
                wn.filterwarnings('error')   # escalate to errors
                try:
                    self.delta = (para1.rrr[4,0] / (-1. * para1.rrr[2,0])) - 1.
                    self.delta /= (2. * fak)
                    self.epsilon = para1.rrr[2,0] / (2. * rat) + self.delta
                # catch
                except (OverflowError, ZeroDivisionError, FloatingPointError)\
                as msg:
                    text = (
                        "\nThomsen.sqr_para1_to_sv_thomsen:"
                        +
                        " SV inversion for near-isotropy bangs!")
                    print(text)
                    print(msg)
                    sys.exit()
        # default other parameters
        self.gamma = 0.   # no information
        # density
        self.rho = para1.rho
        # check stability
        _ = Voigt().thomsen_to_voigt(thomsen=cp(self), flag=None)
        # print
        if flag['print']:
            self._printer()
        # return
        return self

    def _printer(self):
        """
        Print Thomsen's anisotropy parameters.

        Returns
        -------
        self : Thomsen

        """
        # print
        text = "\nThomsen anisotropy parameters:"
        text += f"\nvp0: {self.vp0:8.3f}"
        text += f"\nvs0: {self.vs0:8.3f}"
        text += f"\n\u03B4: {self.delta:+2.6f}"
        text += f"\n\u03B5: {self.epsilon:+2.6f}"
        if self.gamma is not None:
            text += f"\n\u03B3: {self.gamma:+2.6f}"
        if self.rho is not None:
            if self.rho != 1.:
                text += f"\n\u03C1: {self.rho:8.3f}"
        print(text)
        # return
        return self
