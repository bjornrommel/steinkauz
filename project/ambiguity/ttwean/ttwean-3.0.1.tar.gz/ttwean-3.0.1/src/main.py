# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# --- imports -----------------------------------------------------------------


# Python imports
import contextlib as ctl               # context manager
import io                              # in-/output
import numpy as np                     # import numpy
from matplotlib import pyplot as plt   # pyplot


# ttwean imports
import ttwean as tt   # import ttwean


def example01():
    """
    Demo the input of incidence angles.

    The input is designed for equally spaced incidence angles. However, nowhere
    are incidence angles required to be spaced equally; change as you see fit.

    The single angle is designed for use with ttcrpy. The input simply maps it
    into the same structure as required everywhere else.

    Returns
    -------
    Angle : incidence angles

    """
    # pylint:disable=unused-variable
    # call input_to_angles for multiple angles
    print("\ntesting input of multiple angles:")
    angle = (
        tt.input_to_angles(
            start=tt.START, end=tt.END, nos=tt.NOS,
            flag={'print': tt.ANGLEPRINT}))
    # call input_to_angle for a single angle
    print("\ntesting input of a single angle:")
    angle = (
        tt.input_to_angle(
            angle=tt.ANGLE, flag={'print': tt.ANGLEPRINT}))
    # return
    return angle


def example02():
    """
    Demo the input of Thomsen's anisotropy parameters.

    In fact, it asks for P-reference, S-reference velocities, the actual
    Thomsen's anisotropy parameters, and density. That's a bit more than just
    Thomsen's anisotropy parameters, but very helpful.

    Returns
    -------
    Thomsen : Thomsen's anisotropy parameters

    """
    # pylint:disable=unused-variable
    # call input_to_thomsen
    print("\ntesting input of Thomsen's anisotropy parameters:")
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO, flag={'print': tt.THOMSENPRINT}))
    # return
    return thomsen


def example03():
    """
    Demo the computation of a stiffness by Thomsen's anisotropy parameters.

    It converts Thomsen's anisotropy parameters, see example 2, to stiffness
    plus density.

    Returns
    -------
    Voigt : stiffness in Voigt's notation

    """
    # pylint:disable=unused-variable
    # call input_to_thomsen and thomsen_to_voigt
    print("\ntesting input of a stiffness:")
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO, flag={'print': tt.THOMSENPRINT}))
    voigt = (
        tt.thomsen_to_voigt(
            thomsen=thomsen, csign=+1, flag={'print': tt.ELASTICITYPRINT}))
    # return
    return voigt


def example04():
    """
    Demo the computation of phase-velocity parameters.

    v^2 = v0^2 * (1 + r2 * sin(theta)^2 + r4 * sin(theta)^4)   # squared
    v = v0 * (1 + o2 * sin(theta)^2 + o4 * sin(theta)^4)       # linear

    Returns
    -------
    Para1 : phase-velocity parameters incl. reference velocity, density

    """
    # pylint:disable=unused-variable
    # call input_to_thomsen and thomsen_to_p_para1
    print("\ntesting input of phase-velocity parameters ...")
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO, flag={'print': tt.THOMSENPRINT}))
    # ... for a P-wave
    print("\n... for a P-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="P", flag={'print': tt.PARA1PRINT}))
    # ... for an SV-wave
    print("\n... for an SV-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="SV", flag={'print': tt.PARA1PRINT}))
    # return (select any above)
    return para1


def example05():
    """
    Demo the computation of stretched phase-velocity parameters.

    It stretches phase-velocity parameters.

    Returns
    -------
    Para1 : stretched phase-velocity parameters incl. reference velocity

    """
    # pylint:disable=unused-variable
    # call input_to_thomsen, thomsen_to_para1, and stretch_para1
    print("\ntesting the stretch of P phase-velocity parameters:")
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO, flag={'print': tt.THOMSENPRINT}))
    # ... for a P-wave
    print("\n... for a P-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="P", flag={'print': tt.PARA1PRINT}))
    para1 = (
        tt.stretch_para1(
            para1=para1, ggg=tt.GGG, flag={'print': tt.PARA1PRINT}))
    # ... for an SV-wave
    print("\n... for an SV-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="SV", flag={'print': tt.PARA1PRINT}))
    para1 = (
        tt.stretch_para1(
            para1=para1, ggg=tt.GGG, flag={'print': tt.PARA1PRINT}))
    # return (select any above)
    return para1


def example06():
    """
    Demo the computation of energy-velocity parameters.


    v^2 = v0^2 * (1 + r2 * sin(theta)^2 + r4 * sin(theta)^4)   # squared
    v = v0 * (1 + o2 * sin(theta)^2 + o4 * sin(theta)^4)       # linear

    Returns
    -------
    Para2 : energy-velocity parameters

    """
    # pylint:disable=unused-variable
    # call input_to_thomsen, thomsen_to_p_sqr_para2, and para1_to_lin_para2
    print("\ntesting input of energy-velocity parameters ...")
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO, flag={'print': tt.THOMSENPRINT}))
    # ... for a P-wave
    print("\n... for a P-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="P", flag={'print': tt.PARA1PRINT}))
    para2 = (
        tt.para1_to_para2(para1=para1, flag={'print': tt.PARA2PRINT}))
    # ... for an SV-wave
    print("\n... for an SV-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="SV", flag={'print': tt.PARA1PRINT}))
    para2 = (
        tt.para1_to_para2(para1=para1, flag={'print': tt.PARA2PRINT}))
    # return (select any above)
    return para2


def example07():
    """
    Demo the computation of stretched energy-velocity parameters.

    Returns
    -------
    Para2 : stretched energy-velocity parameters

    """
    # pylint:disable=unused-variable
    # call input_to_thomsen, thomsen_to_p_para1, stretch_para1, and
    # para1_to_lin_para2
    print("\ntesting the stretch of P energy-velocity parameters:")
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO, flag={'print': tt.THOMSENPRINT}))
    # ... for a P-wave
    print("\n... for a P-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="P", flag={'print': tt.PARA1PRINT}))
    para1 = (
        tt.stretch_para1(
            para1=para1, ggg=tt.GGG, flag={'print': tt.PARA1PRINT}))
    para2 = (
        tt.para1_to_para2(
            para1=para1, flag={'print': tt.PARA2PRINT}))
    # ... for an SV-wave
    print("\n... for an SV-wave:")
    para1 = (
        tt.thomsen_to_para1(
            thomsen=thomsen, wavetype="SV", flag={'print': tt.PARA1PRINT}))
    para1 = (
        tt.stretch_para1(
            para1=para1, ggg=tt.GGG, flag={'print': tt.PARA1PRINT}))
    para2 = (
        tt.para1_to_para2(para1=para1, flag={'print': tt.PARA2PRINT}))
    # return
    return para2


def example08():
    """
    Demo the computation of an exact phase velocity via Voigt's stiffness.

    Note the structure for plotting velocity-versus angle curves:
        # entire figure
        figure = tt.Figure(title=, num=, figsize=)
            title : str
                figure title
            num : str or int
                unique figure identifier (found in the window header)
                can safely be ignored
            figsize : tupel
                (width, height) of figure in inch
                see default FIGSIZE in usr.py
        # velocity (polar) axis
        raxis = tt.Axis(amin=, step=, amax=)
            amin : float
                minimum offset, default 0.
            step : int
                spacing of offset ticks, defaults such as to produce 6 ticks
            amax : float
                maximum offset, defauls to ceil(max offset / 10) * 10
        # graphic properties
        graphics =
            tt.VelocityGraphics(toolkit=, figure=, xaxis=, yaxis=)
            toolkit : str
                GUI builder, on my system
                    'qt' for a separate window
                    'inline' within the console
                    'notebook' for a Jupyter Notebook
                figure, xaxis, yaxis as above
        # graphic properties update
        phaseplot = tt.pt(graphics.input_to_graphics, label=)
            label : str
                graph label
        phaseplot is a function updating the graph label
        # parameter
        flag['plot'] = phaseplot(label=)
            label : str
                graph label
        phaseplot, see above, updated the graph label, and the entire set of
        graphic properties is passed to ttwean through flag['plot'] =


    Returns
    -------
    VoigtPhaseVelocity : exact phase velocity from Voigt's stiffness

    """
    # pylint:disable=unused-variable
    # call input_to_angles, input_to_thomsen, thomsen_to_voigt, and
    # voigt_exact_phase
    # define graphics
    figure = (
        tt.Figure(
            title=tt.TITLE+": Exact / Approximate Phase Velocities",
            num="example 08", block=tt.BLOCK, figsize=tt.FIGSIZE))
    raxis = tt.Axis(amax=2500,)
    graphics = tt.VelocityGraphics(
        toolkit = tt.TOOLKIT, figure=figure, raxis=raxis)
    phaseplot = tt.pt(graphics.input_to_graphics)
    # incidence phase angles
    angle = (
        tt.input_to_angles(
            start=tt.START, end=tt.END, nos=tt.NOS,
            flag={'print': False, 'plot': False}))
    # Thomsen's anisotropy parameters
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO, flag={'print': False, 'plot': False}))
    # stiffness in Voigt notation
    voigt = (
        tt.thomsen_to_voigt(
            thomsen=thomsen, flag={'print': False, 'plot': False}))
    # phase velocity for a P-wave
    phase = (
        tt.voigt_to_exact_phase(
            voigt=voigt, angle=angle, wavetype="P",
            flag={
                'print': tt.VOIGTPHASEPRINT,
                'plot': phaseplot(label="P exact")}))
    # phase velocity for an SV-wave
    phase = (
        tt.voigt_to_exact_phase(
            voigt=voigt, angle=angle, wavetype="SV",
            flag={
                'print': tt.VOIGTPHASEPRINT,
                'plot': phaseplot(label="SV exact")}))
    # close phase plot
    graphics.close()
    # return
    return phase


def example09():
    """
    Demo the computation of an exact / linearized phase velocity.

    Note, the computation is still exact and must, within numerics, match that
    in example 08.

    Returns
    -------
    ThomsenPhaseVelocity: exact phase velocity from Thomsen's parameters

    """
    # pylint:disable=unused-variable
    # call input_to_angles, input_to_thomsen, thomsen_to_voigt, and
    # voigt_to_p_phase
    # define graphics
    figure = (
        tt.Figure(
            title=tt.TITLE+": Exact / Approximate Phase Velocities",
            num="example 09", block=tt.BLOCK, figsize=tt.FIGSIZE))
    raxis = tt.Axis(amax=2500,)
    graphics = tt.VelocityGraphics(
        toolkit = tt.TOOLKIT, figure=figure, raxis=raxis)
    phaseplot = tt.pt(graphics.input_to_graphics)
    angle = (
        tt.input_to_angles(start=tt.START, end=tt.END, nos=tt.NOS))
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO))
    # ... for a P-wave
    phase = (
        tt.thomsen_to_exact_phase(
            thomsen=thomsen, angle=angle, wavetype="P",
            flag={
                'print': tt.VOIGTPHASEPRINT,
                'plot': phaseplot(label="P exact")}))
    # ... for an SV-wave
    phase = (
        tt.thomsen_to_exact_phase(
            thomsen=thomsen, angle=angle, wavetype="SV",
            flag={
                'print': tt.VOIGTPHASEPRINT,
                'plot': phaseplot(label="SV exact")}))
    # ... for a linearized P-wave
    para1 = (
        tt.thomsen_to_para1(thomsen=thomsen, wavetype="P"))
    phase = tt.para1_to_approx_phase(
        para1=para1, angle=angle, wavetype="P",
        flag={
            'print': tt.APPROXPHASEPRINT,
            'plot': phaseplot(label="P linear")})
    # ... for a linearized SV-wave
    para1 = (
        tt.thomsen_to_para1(thomsen=thomsen, wavetype="SV"))
    phase = tt.para1_to_approx_phase(
        para1=para1, angle=angle, wavetype="SV",
        flag={
            'print': tt.APPROXPHASEPRINT,
            'plot': phaseplot(label="SV linear")})
    # close plot
    graphics.close()
    # return
    return phase


def example10():
    """
    Demo the computation of an exact phase velocity via Voigt or Thomsen's
    parameters.

    Note, the computation is exact and must, within numerics, match; the
    difference must be zero.

    Returns
    -------
    None

    """
    # pylint:disable=unused-variable
    # call input_to_angles, input_to_thomsen, thomsen_to_voigt, and
    # voigt_to_p_phase
    angle = (
        tt.input_to_angles(start=tt.START, end=tt.END, nos=tt.NOS))
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO))
    voigt = (
        tt.thomsen_to_voigt(thomsen=thomsen, csign=+1))
    # ... with version 1
    voigt_phase = (
        tt.voigt_to_exact_phase(
            voigt=voigt, angle=angle, wavetype="P"))
    # ... with version 2
    thomsen_phase = (
        tt.thomsen_to_exact_phase(
            thomsen=thomsen, angle=angle, wavetype="P"))
    # compare
    print("\ncomparing phase velocities:")
    print(voigt_phase.mag.abs - thomsen_phase.mag.abs)


def example11():
    """
    Demo the computation of exact and linearized energy velocities.

    """
    # pylint:disable=unused-variable
    # call input_to_angles, input_to_thomsen, thomsen_to_voigt, and
    # voigt_to_p_phase
    # define graphics
    figure = (
        tt.Figure(
            title=tt.TITLE+": Exact Energy Velocities",
            num="example 11", block=tt.BLOCK, figsize=tt.FIGSIZE))
    raxis = tt.Axis(amax=2500,)
    graphics = tt.VelocityGraphics(
        toolkit = tt.TOOLKIT, figure=figure, raxis=raxis)
    energyplot = tt.pt(graphics.input_to_graphics)
    # get the incidence angles
    angle = (
        tt.input_to_angles(start=tt.START, end=tt.END, nos=tt.NOS))
    # get Thomsen's anisotropy parameter to characterize stiffness
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO))
    # ... for a P-wave
    # compute the exact phase velocity
    phase = (
        tt.thomsen_to_exact_phase(
            thomsen=thomsen, angle=angle, wavetype="P",
            flag={'print': tt.VOIGTPHASEPRINT, 'plot': False}))
    # compute the energy-velocity parameters
    _, para2 = tt.thomsen_to_para2(thomsen=thomsen, wavetype="P")
    # compute the exact energy velocity (from the exact phase velocity)
    energy = (
        tt.phase_to_exact_energy(
            phase=phase,
            flag={
                'print': tt.ENERGYPRINT,
                'plot': energyplot(label="P exact")}))
    # compute the exactly stretched energy velocity (overwriting!)
    energy.stretch(
        ggg=tt.GGG,
        flag={
            'print': tt.ENERGYPRINT,
            'plot': energyplot(label="P exact stretch (Rommel)")})
    # compute the approximate energy velocity
    _ = (
        tt.para2_to_approx_energy(
            para2=para2, angle=angle, wavetype="P",
            flag={
                'print': tt.APPROXENERGYPRINT,
                'plot': energyplot(label="P linear (Rommel)")}))
    # compute the stretched energy-velocity parameters
    _, para2 = tt.thomsen_to_para2(thomsen=thomsen, wavetype="P", ggg=tt.GGG)
    # compute the approximately stretched energy velocity
    energy = (
        tt.para2_to_approx_energy(
            para2=para2, angle=angle, wavetype="P",
            flag={
                'print': tt.APPROXENERGYPRINT,
                'plot': energyplot(label="P linear (Rommel)")}))
    # ... for an SV-wave
    # compute the exact phase velocity
    phase = (
        tt.thomsen_to_exact_phase(
            thomsen=thomsen, angle=angle, wavetype="SV",
            flag={'print': False, 'plot': False}))
    # compute the energy-velocity parameters
    _, para2 = tt.thomsen_to_para2(thomsen=thomsen, wavetype="SV")
    # compute the exact energy velocity
    energy = (
        tt.phase_to_exact_energy(
            phase=phase,
            flag={
                'print': tt.ENERGYPRINT,
                'plot' : energyplot(label="SV exact")}))
    # compute the exactly stretched energy velocity
    energy.stretch(
        ggg=tt.GGG,
        flag={
            'print': tt.ENERGYPRINT,
            'plot': energyplot(label="SV exact stretch (Rommel)")})
    # compute the approximate energy velocity
    _ = (
        tt.para2_to_approx_energy(
            para2=para2, angle=angle, wavetype="SV",
            flag={
                'print': tt.APPROXENERGYPRINT,
                'plot': energyplot(label="SV linear (Rommel)")}))
    # compute the stretched energy-velocity parameters
    _, para2 = tt.thomsen_to_para2(thomsen=thomsen, wavetype="SV", ggg=tt.GGG)
    # compute the approximately stretched energy velocity
    energy = (
        tt.para2_to_approx_energy(
            para2=para2, angle=angle, wavetype="SV",
            flag={
                'print': tt.APPROXENERGYPRINT,
                'plot': energyplot(label="SV linear (Rommel)")}))
    # close plot
    graphics.close()


def example12():
    """
    Demo the computation of a traveltime.

    Note the structure for plotting traveltime-offset curves:
        # entire figure
        figure = tt.Figure(title=, num=, figsize=)
            title : str
                figure title
            num : str or int
                unique figure identifier (found in the window header)
                can safely be ignored
            figsize : tupel
                (width, height) of figure in inch
                see default FIGSIZE in usr.py
        # offset axis
        xaxis = tt.Axis(amin=, step=, amax=)
            amin : float
                minimum offset, default 0.
            step : int
                spacing of offset ticks, defaults such as to produce 6 ticks
            amax : float
                maximum offset, defauls to ceil(max offset / 10) * 10
        # traveltime axis
        yaxis = tt.Axis(amin=, step=, amax=)
        # graphic properties
        graphics =
            tt.TraveltimeOffsetGraphics(toolkit=, figure=, xaxis=, yaxis=)
            toolkit : str
                GUI builder, on my system
                    'qt' for a separate window
                    'inline' within the console
                    'notebook' for a Jupyter Notebook
                figure, xaxis, yaxis as above
        # graphic properties update
        travelplot = tt.pt(graphics.input_to_graphics, label=)
            label : str
                graph label
        travelplot is a function updating the graph label
        # parameter
        flag['plot'] = travelplot(label=)
            label : str
                graph label
        travelplot, see above, updated the graph label, and the entire set of
        graphic properties is passed to ttwean through flag['plot'] =


    Returns
    -------
    Traveltime

    """
    # pylint:disable=unused-variable
    # define graphics for all traveltime-offset graphs
    figure = (
        tt.Figure(
            title=tt.TITLE+": Traveltime-Offset Curve",
            num="example 12", block=tt.BLOCK, figsize=tt.FIGSIZE))
    xaxis = tt.Axis()   # derived from user input
    yaxis = tt.Axis(amin=0.26, step=0.01, amax=0.36)
    graphics = (
        tt.TraveltimeOffsetGraphics(
            toolkit=tt.TOOLKIT, figure=figure, xaxis=xaxis, yaxis=yaxis))
    # define function to adjust graphics for each single graph
    travelplot = tt.pt(graphics.input_to_graphics, label=None)
    # incidence angles (beyond final offset)
    angle = (
        tt.input_to_angles(start=tt.START, end=tt.END, nos=tt.NOS))
    # exact energy velocity and traveltime-offsets before/after stretch
    thomsen = (
        tt.input_to_thomsen(
            vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
            gamma=tt.GAMMA, rho=tt.RHO))
    phase = (
        tt.thomsen_to_exact_phase(
            thomsen=thomsen, angle=angle, wavetype="P",
            flag={'print': False, 'plot': False}))
    energy = (
        tt.phase_to_exact_energy(
            phase=phase, flag={'print': False, 'plot': False}))
    tplot1 = tt.traveltime_offset(
        energy=energy, depth=tt.DEPTH, offset=tt.OFFSET,
        flag={
            'print': tt.TRAVELPRINT,
            'plot': travelplot(label="P exact before")})
    energy.stretch(ggg=tt.GGG)
    tplot2 = tt.traveltime_offset(
        energy=energy, depth=tt.DEPTH*np.sqrt(1.+tt.GGG), offset=tt.OFFSET,
        flag={
            'print': tt.TRAVELPRINT,
            'plot': travelplot(label="P exact after")})
    # linear energy velocity and traveltime-offsets
    _, para2 = (
        tt.thomsen_to_para2(thomsen=thomsen, wavetype="P"))
    energy = tt.para2_to_approx_energy(para2=para2, angle=angle, wavetype="P")
    tplot3 = tt.traveltime_offset(
        energy=energy, depth=tt.DEPTH, offset=tt.OFFSET,
        flag={
            'print': tt.TRAVELPRINT,
            'plot': travelplot(label="P linear before")})
    _, para2 = (
        tt.thomsen_to_para2(thomsen=thomsen, wavetype="P", ggg=tt.GGG))
    energy = tt.para2_to_approx_energy(para2=para2, angle=angle, wavetype="P")
    tplot4 = tt.traveltime_offset(
        energy=energy, depth=tt.DEPTH*np.sqrt(1.+tt.GGG), offset=tt.OFFSET,
        flag={
            'print': tt.TRAVELPRINT,
            'plot': travelplot(label="P linear after")})
    # close graphics
    graphics.close(tplot1, tplot2, tplot3, tplot4)


def ttcrpy(
        vp0=tt.VP0, vs0=tt.VS0, delta=tt.DELTA, epsilon=tt.EPSILON,
        wavetype="P", ggg=tt.GGG, angle=np.deg2rad(tt.ANGLE)):
    """
    Demonstrate ttwean's use for Giroux's simulation package ttcpry.

    Reference for input:
    Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

    ttinit must be run for each medium, wavetype, and/or stretch once. It is
    the user's responsibility to assign the correct output to each cell. See
    Giroux's Jupyter notebook for details.
    ttvel must be run for each incidence angle, and it would be valid, albeit
    impractical, for all cells of the same medium and for the same wavetype
    and stretch. Typically, though, it would be run for each cell for each time
    step.

    Typically,
        vp0[medium,stretch], vs0[medium,stretch],
        sss[medium,stretch,wavetype] = (
            ttinit(
                vp0=VP0, vs0=VS0, delta=DELTA, epsilon=EPSILON,
                wavetype="P" or wavetype="SV", ggg=GGG))
        vel[wavetype,angle,cell] = (
            ttvel(
                vp0=vp0[medium,stretch], vs0=vs0[medium,stretch],
                sss=sss[medium,stretch], wavetype=wavetype, angle=ANGLE)
    Note, all capital for user-defined parameters.
    Any stretch modifies P and SV-velocities: so, be careful not to overwrite
    your in- and output variable.
    Use the same wavetype for ttinit and ttray.

    ttcpry produces an energy velocity
        v(phi) = v0 * (1 + s2 * sin^2 (phi) + s4 * sin^2 (phi))

    Parameters
    ----------
    vp0 : float
        reference P-velocity
    vs0 : float
        reference S-velocity
    delta : float, default is 0.
        Thomsen parameter delta
    epsilon : float, default is 0.
        Thomsen parameter epsilon
    wavetype : char
        "P" : P-wave
        "SV" : S-wave
    ggg : float, default is 0. (neutral)
        stretch factor
    angle : float
        incidence angle in radiant

    """
    # pylint:disable=too-many-arguments   # needed and understandable
    # pylint:disable=unused-variable   # for velocity
    # forward to pre-compute the linear energy-velocity parameters
    vp0, vs0, sss = (  # NOQA
        tt.ttinit(
            vp0=vp0, vs0=vs0, delta=delta, epsilon=epsilon, wavetype=wavetype,
            ggg=ggg))
    # forward to compute the energy velocity
    vel = (  # NOQA
        tt.ttvel(
            vp0=vp0, vs0=vs0, sss=sss, wavetype=wavetype, angle=angle))


# --- main --------------------------------------------------------------------


if __name__ == "__main__":
    # for Giroux's simulation package ttcrpy
    ttcrpy()
    # for demos showing all available commands
    with ctl.redirect_stdout(io.StringIO()):   # kills print; (un)comment
        example = [
            example01, example02, example03, example04, example05,
            example06, example07, example08, example09, example10,
            example11, example12]
        for eee, func in enumerate(example):
            # run example eee
            print(f"\nrunning example {eee+1}:")
            _ = func()
        # ### plt.show(block=True)   # block graphics when using 'python main'
    # check Matplotlib's backend
    # ### print(plt.get_backend())
    