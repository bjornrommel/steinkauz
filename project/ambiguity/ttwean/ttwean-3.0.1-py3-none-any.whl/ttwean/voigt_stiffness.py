# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-01-28
"""


# Python imports
import numpy as np   # numpy library


# define Voigt
class Voigt():
    """
    Characterize stiffness in Voigt notation and include density.

    Note, ccc is an np.array ([7x7]), where row=0 and column=0 are zeroed out
    so that c_ij corresponds to ccc[i,j].

    """

    # initialize
    def __init__(self):
        """
        Initialize stiffness matrix in Voigt notation and density.

        Returns
        -------
        self :
            ccc : np.array ([7x7])
                elasticity in Voigt's notation
            rho : float
                density
        Note, row=0 and column=0 are zeroed out so that c_ij corresponds to
        ccc[i,j].

        """
        # init
        self.ccc = np.full((7,7), fill_value=0., dtype=float)   # stiffness
        self.rho = 0.                                           # density

    # set up VTI stiffness matrix
    def input_to_voigt(
            self, c11=None, c13=None, c33=None, c44=None, c66=None, rho=None,
            flag=None):
        """
        Set up VTI stiffness matrix in Voigt notation and density.

        Parameters
        ----------
        c11=c33, c13=c33-2*c44, c33, c44, c66=c44 : float
            elasticity parameters c11, c13, c44, c66
        rho : float
            density
        flag : dict 
            'print' : boolean
                print
        Note, c33, c44 are required; otherwise, isotropy is default.

        Returns
        -------
        self :
            ccc : np.array ([7x7])
                elasticity in Voigt's notation
            rho : float
                density
        Note, row=0 and column=0 are zeroed out so that c_ij corresponds to
        ccc[i,j].

        """
        # pylint:disable=too-many-arguments
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # check parameters
        check = c33 is not None
        text = "Voigt.input_to_voigt: c33 is None!"
        assert check, text
        check = c44 is not None
        text = "Voigt.input_to_voigt: c44 is None!"
        assert check, text
        check = rho is not None
        text = "Voigt.input_to_voigt: rho is None!"
        assert check, text
        # default parameters to isotropy
        if c11 is None:
            c11 = c33
        if c13 is None:
            c13 = c33 - 2 * c44
        if c66 is None:
            c66 = c44
        # set elasticity in Voigt's notation
        self.ccc = np.full((7,7), fill_value=0., dtype=float)   # init
        self.ccc[3,3] = c33
        self.ccc[4,4] = self.ccc[5,5] = c44
        self.ccc[6,6] = c66
        self.ccc[1,2] = self.ccc[2,1] = c11 - 2 * c66
        self.ccc[1,3] = self.ccc[3,1] = c13
        self.ccc[2,3] = self.ccc[3,2] = c13
        # check stability (after having filled Voigt's elasticity matrix)
        self._stability()
        # check density
        check = rho > 0.
        text = f"input_to_voigt: density {rho} !> 0.!"
        assert check, text
        # set density
        self.rho = rho
        # print
        if flag['print']:
            _ = self._printer()
        # return
        return self

    # convert reference velocities + Thomsen's anisotropy parameters
    def thomsen_to_voigt(self, thomsen=None, csign=+1, flag=None):
        """
        Convert velocities + Thomsen anisotropy parameters to Voigt elasticity.

        Note, strictly, c13 = +/-SQRT() - c[4,4] below, but the negative sign
        is unlikely to be the case in seismics.

        Thomsen, L., 1986, Weak elastic anisotropy: GEOPHYSICS, 51, 1954-1966.

        Parameters
        ----------
        thomsen : Thomsen's anisotropy parameters
            vp0 : float
                P-velocity
            vs0 : float
                S-velocity
            delta : float, default 0.
                Thomsen anisotropy parameter delta
            epsilon : float, default 0.
                Thomsen anisotropy parameter epsilon
            gamma : float, default 0.
                Thomsen anisotropy parameter gamma
            rho : float
                density
        csign : float, default +1, requirement +/-1.
            sign occuring in conversion from delta to c13, typically +1.
        flag : dict 
            'print' : boolean
                print
            
        Returns
        -------
        self : Voigt
            ccc : np.array ([7x7])
                elasticity in Voigt's notation
            rho : float
                density
        Note, row=0 and column=0 are zeroed out so that c_ij corresponds to
        ccc[i,j].
        
        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # check sign
        check = csign in (-1., +1.)
        text = "Voigt.thomsen_to_voigt: invalid sign {sign}!"
        assert check, text
        # density
        self.rho = thomsen.rho
        # compute specific elasticity elements from input
        self.ccc[3,3] = thomsen.vp0 ** 2 * self.rho
        self.ccc[4,4] = self.ccc[5,5] = thomsen.vs0 ** 2 * self.rho
        self.ccc[6,6] = self.ccc[4,4] * (1. + 2. * thomsen.gamma)
        self.ccc[1,2] = self.ccc[1,3] = self.ccc[2,3] = (
            csign * np.sqrt(
                (self.ccc[3,3] - self.ccc[4,4])
                *
                (self.ccc[3,3] - self.ccc[4,4] +
                 2 * self.ccc[3,3] * thomsen.delta)
            )
            -
            self.ccc[4,4])
        self.ccc[2,1] = self.ccc[3,1] = self.ccc[3,2] = self.ccc[1,2]
        self.ccc[1,1] = self.ccc[2,2] = (
            self.ccc[3,3] * (1. + 2. * thomsen.epsilon))
        # check stability (determinant must be positive for stability)
        self._stability()
        # print
        if flag['print']:
            _ = self._printer()
        # return
        return self

    def _printer(self):
        """
        Print stiffness.

        Returns
        -------
        self : Voigt

        """
        # print
        text = "\nstiffness in Voigt's notation':\n"
        text += (
            "\n".join([
                "".join([
                    f"{item:8.3e} " for item in row[1:7]])
                for row in self.ccc[1:7]]))
        print(text)
        # return
        return self

    # check stability
    def _stability(self):
        """
        Check the stability of a stiffness matrix.

        Returns
        -------
        self : Voigt

        """
        # check stability (determinant must be positive for stability)
        check = np.linalg.det(self.ccc[1:7,1:7]) > 0.
        text = "Voigt.stability: stability criterion not met!"
        assert check, text
        # return
        return self
