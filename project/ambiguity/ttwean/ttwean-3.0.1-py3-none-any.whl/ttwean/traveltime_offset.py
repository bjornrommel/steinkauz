# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
import sys                             # sys
import warnings as wn                  # warnings
from scipy import interpolate as si    # scipy.interpolate
import numpy as np                     # numpy


# ttwean imports
from .user import DXX   # receiver spacing


class TraveltimeOffset():
    """
    Characterize traveltime-versus-offset.

    """
    # pylint:disable=too-few-public-methods

    # initialize
    def __init__(self):
        """
        Initialize traveltime-versus-offset.

        """
        self.offset = None     # offset
        self.depth = None      # depth of reflector
        self.distance = None   # distance travelled
        self.time = None       # traveltime
        self.xxx = None        # interpolated graphics offsets
        self.yyy = None        # interpolated graphics traveltimes
        self.nos = None        # number of traveltime-offset pairs

    # compute traveltime-offset
    def traveltime_offset(
            self, energy=None, depth=None, offset=None, flag=False, ref=None):
        """
        Compute traveltime with a virtual source at depth.

        Parameters
        ----------
        energy : EnergyVelocity
            energy velocity
        depth : float
            depth of reflector
        offset : float
            max offset
        flag : dict
            'print' : boolean
                print
            'plot' : boolean or TraveltimeOffsetGraphics
                plot traveltime-offset
        ref : None or TravelOffset
            traveltime to substract

        """
        # pylint:disable=broad-exception-caught, too-many-arguments

        # prepare traveltime-offset curves
        def _graphics(offset=None):
            """
            Prepare traveltime-offset curves.

            """
            # flatten
            xxx = self.offset.flatten()   # offset as x coord
            yyy = self.time.flatten()     # time as y coord
            # interpolation polynomial
            scs = (
                si.CubicSpline(
                    xxx, yyy, bc_type=('not-a-knot', 'not-a-knot')))
            # re-sample
            imax = int(np.floor(offset / DXX)) + 1                # samples
            xxx = (
                np.array(
                    [iii * float(DXX) for iii in range(imax)]))   # re-sampled
            yyy = scs(xxx, 0)                                     # interpolat.
            # return
            return xxx, yyy

        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # copy
        self.depth = float(depth)
        # be wary: tangent -> infinity, offset, distance -> infinity
        with np.errstate(all = 'raise'):     # numpy warnings
            with wn.catch_warnings():        # other warnings
                wn.filterwarnings('error')   # escalate to errors
                try:
                    # offset
                    self.offset = self.depth * np.tan(energy.rad)
                    # distance
                    self.distance = np.sqrt(self.depth ** 2 + self.offset ** 2)
                    # traveltime
                    self.time = self.distance / energy.mag.abs
                except ValueError as msg:   # how possible?
                    print("TravelOffset.traveltime")
                    sys.exit(msg)
                # catch infinite tangent, zero velocity
                except (OverflowError, ZeroDivisionError) as msg:
                    print("TravelOffset.traveltime")
                    sys.exit(msg)
                except FloatingPointError as msg:
                    print("TravelOffset.traveltime")
                    sys.exit(msg)
                except Exception as msg:   # what else?
                    print("TravelOffset.traveltime")
                    sys.exit(msg)
                else:
                    pass
        # prepare graphics
        self.xxx, self.yyy = _graphics(offset=offset)
        # do difference
        if ref is not None:
            self.yyy -= ref.yyy
        # print
        if flag['print']:
            _ = self._printer()
        # graphics
        if flag['plot']:
            _= self._plotter(plot=flag['plot'])
        # return
        return self

    def _printer(self):
        """
        Print traveltime-offset points.

        Returns
        -------
        self

        """
        # print
        print("\ntraveltime-offset curve:")
        text = (
            "\n".join([
                f"{self.xxx[iii]:7.3f}" +
                ", " +
                f"{self.yyy[iii]:8.6f}"
                for iii in range(self.xxx.size)]))
        print(text)
        # return
        return self

    def _plotter(self, plot=None):
        """
        Plot traveltime-offset points.

        Parameters
        ----------
        plot : TraveltimeOffsetGraphics
            user-defined plot commands

        Returns
        -------
        self

        """
        # plot
        plot.cartesian(xxx=self.xxx, yyy=self.yyy)
        # return
        return self
