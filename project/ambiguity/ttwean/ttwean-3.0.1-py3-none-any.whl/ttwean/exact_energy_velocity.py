# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
import numpy as np   # numpy


# ttwean imports
from .velocity import Velocity
from .constant import WVT


class ExactEnergyVelocity(Velocity):
    """
    Characterize an energy velocity.

    """

    def __init__(self):
        """
        Initialize an energy velocity.

        """
        # inherit
        super().__init__()
        # init
        self.sign = None   # P-/S-wavetype

    def exact_energy(self, phase=None, flag=None):
        """
        Compute energy velocity from exact phase velocity via Berryman.

        w(phi) =
            Sqrt[
                v(theta)^2 + dv(theta)^2]
        tan(phi) =
            (tan(theta) + dv(theta)/v(theta))
            /
            (1 - tan(theta) * dv(theta)/v(theta))

        Parameters
        ----------
        phase : PhaseVelocity
            phase velocity
        flag : dict
            'print' : boolean
                print
            'plot' : boolean or VelocityGraphics
                plot

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # reference velocity
        self.vp0 = phase.vp0
        self.vs0 = phase.vs0
        # magnitude of energy velocity
        self.mag.abs = (
            np.sqrt(
                phase.mag.abs * phase.mag.abs
                +
                phase.dmag.abs * phase.dmag.abs))
        # angle of energy velocity
        tan = np.tan(phase.rad)
        fak = phase.dmag.abs / phase.mag.abs
        self.rad = np.arctan((tan + fak) / (1. - tan * fak))
        self.grad = np.rad2deg(self.rad)
        # components
        self.mag.xxx = self.mag.abs * np.sin(self.rad)
        self.mag.zzz = self.mag.abs * np.cos(self.rad)
        # number
        self.nos = phase.nos
        # wavetype flag
        self.sign = phase.sign
        # graphics
        if flag['plot']:
            if flag['plot'].label is None:
                flag['plot'].label = f"{WVT[self.sign]}" + "energy (Berryman)"
            self.plotter(plot=flag['plot'])
        # print
        if flag['print']:
            # pylint:disable=invalid-name   # what's constant about "text"
            print("\nexact energy angle, velocity and its components:")
            text = (
                "\n".join([
                    f"{self.grad[iii,0]:9.6f}" +
                    ", " +
                    f"{self.mag.abs[iii,0]:11.6f}" +
                    ", " +
                    f"{self.mag.xxx[iii,0]:11.6f}"
                    ", " +
                    f"{self.mag.zzz[iii,0]:11.6f}"
                    for iii in range(self.nos)]))
            print(text)
        # return
        return self

    def stretch(self, ggg=0., flag=None):
        """
        Compute a stretched exact energy velocity from an energy velocity.

        wx'(phi) = wx(phi)
        wz'(phi) = wz(phi) * Sqrt[1 + g]

        Parameters
        ----------
        ggg : float, default to 0.
            stretch parameter
        flag : dict 
            'print' : boolean
                print
            'plot' : boolean or VelocityGraphics
                plot

        Returns
        -------
        self : ExactEnergyVelocity
            exact energy velocity

        """
        # flag
        if flag is None:
            flag = {'print': False, 'plot': False}
        # copy stretch factor
        self.ggg = ggg
        # stretch vertical component only
        self.mag.zzz *= np.sqrt(1. + self.ggg)
        self.mag.abs = np.sqrt(self.mag.xxx ** 2 + self.mag.zzz ** 2)
        # stretch incidence angle
        self.rad = np.arctan(1. / np.sqrt(1. + self.ggg) * np.tan(self.rad))
        self.grad = np.rad2deg(self.rad)
        # print
        if flag['print']:
            # pylint:disable=invalid-name   # what's constant about "text"
            print("\nexact energy angle, velocity and its components:")
            text = (
                "\n".join([
                    f"{self.grad[iii,0]:9.6f}" +
                    ", " +
                    f"{self.mag.abs[iii,0]:11.6f}" +
                    ", " +
                    f"{self.mag.xxx[iii,0]:11.6f}"
                    ", " +
                    f"{self.mag.zzz[iii,0]:11.6f}"
                    for iii in range(self.nos)]))
            print(text)
        # plot
        if flag['plot']:
            flag['plot'].radius = self.mag.abs.flatten()
            flag['plot'].direction = self.grad.flatten()
            if flag['plot'].label is None:
                flag['plot'].label = 'test'
            self.plotter(plot=flag['plot'])
        # return
        return self
