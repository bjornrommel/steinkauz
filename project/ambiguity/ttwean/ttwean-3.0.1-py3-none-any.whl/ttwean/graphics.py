# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
from copy import deepcopy as cp        # copy
from matplotlib import pyplot as plt   # pyplot
from IPython import get_ipython        # ipython


class Axis():
    """
    Characterize an axis in matplotlib.

    """
    # pylint:disable=too-few-public-methods

    def __init__(
            self, amin=None, amax=None, step=None, label=None):
        """
        Define the properties of an axis in matplotlib.

        Parameters
        ----------
        amin : float, default minimum found
            minimum value
        amax : float, default maximum found
            maximum value
        step : float, defaults such as to generate 6 ticks
            tick step size
        label : str
            axis label

        Returns
        -------
        self : Axis
            min : float
                minimum value
            max : float
                maximum value
            step : float
                tick step size
            label : str
                axis label

        """
        # define axis properties
        self.amin = amin     # minimum value
        self.amax = amax     # maximum value
        self.step = step     # tick step size
        self.label = label   # axis label


class Figure():
    """
    Characterize a figure.

    """
    # pylint:disable=too-few-public-methods

    def __init__(self, title=None, num=None, block=False, figsize=None):
        """
        Set up a figure.

        Parameters
        ----------
        title : str, optional
            figure title
        num : int or str, optional
            figure identifier (shown in window header)
        block : boolean
            show / don't show
        figsize : tupel
            figure size

        """
        # define figure properties
        self.title = title       # figure title
        self.num = num           # window header
        self.block = block       # block graphics window
        self.figsize = figsize   # figure size


class Graphics():
    """
    Characterie a graphic.

    """
    # pylint:disable=too-few-public-methods

    def __init__(self, toolkit=None, figure=None):
        """
        Set up a graphics.

        Parameters
        ----------
        toolkit : char
            GUI toolkit
                'qt' for use with iPython
                'notebook' for use with Jupyter Notebook
        figure : Figure
            num : int
                figure identifier (found in window header)
            title : char
                title
            figsize : tupel
                figure size

        Returns
        -------
        self : Graphic
            fig : plt.figure
                figure
            axx : plt.figure.add_subplot
                subfigure identifier

        """
        # set figure
        self.figure = figure
        # axes set in CartesianGraphics, PolarGraphics
        # create a (separate) graphics window
        if get_ipython() is not None:
            get_ipython().run_line_magic('matplotlib', toolkit)
        # set up figure
        plt.close(figure.num)
        self.fig = (
            plt.figure(
                num=figure.num, figsize=figure.figsize,
                constrained_layout=True))
        self.axx = self.fig.add_subplot(111)
        # graph label, default to None
        self.label = None

    @staticmethod
    def set_font():
        """
        Define the font styles, sizes used in all SEG-conforming plots.

        Returns
        -------
        None

        """
        # set fonts https://stackoverflow.com/a/39566040
        plt.rc('text', usetex=True)          # Latex for versatility
        plt.rc('font', family='Helvetica')   # fontstyle
        plt.rc('ps', usedistiller='xpdf')    # avoiding bitmap
        plt.rc('font', size=8)               # controls default text sizes
        plt.rc('axes', titlesize=8)          # fontsize of the axes title
        plt.rc('axes', labelsize=8)          # fontsize of the axes labels
        plt.rc('xtick', labelsize=8)         # fontsize of the tick labels
        plt.rc('ytick', labelsize=8)         # fontsize of the tick labels
        plt.rc('legend', fontsize=8)         # legend fontsize
        plt.rc('figure', titlesize=8)        # fontsize of the figure title


class CartesianGraphics(Graphics):
    """
    Characterize a graphic in cartesian coordinates.

    """
    # pylint:disable=too-few-public-methods

    def __init__(
            self, toolkit=None, figure=None, xaxis=None, yaxis=None):
        """
        Set up a graphic in cartesian coordinates.

        Parameters
        ----------
        toolkit : TYPE, optional
            DESCRIPTION. The default is None.
        figure : Figure, optional
            figure properties
            num : int
                figure identifier (found in window header)
            figsize : TYPE, optional
                DESCRIPTION. The default is None.
        xaxis : Axis, optional
            horizontal (e.g., offset) axis
        yaxis : Axis, optional
            vertical (e.g., traveltime) axis



        """
        # inherit
        super().__init__(toolkit=toolkit, figure=figure)
        # define axes
        self.xaxis = cp(xaxis)
        self.yaxis = cp(yaxis)


class PolarGraphics(Graphics):
    """
    Characterize a graphic in polar coordinates.

    """
    # pylint:disable=too-few-public-methods

    def __init__(self, toolkit=None, figure=None, raxis=None):
        """
        Set up a graphic in cartesian coordinates.

        Parameters
        ----------
        figure : Figure, optional
            figure properties
            num : int
                figure identifier (found in window header)
            title : char
                title
            figsize : tupel
                figure size
        raxis : Axis, optional
            radial (e.g., velocity) axis
        toolkit : TYPE, optional
            DESCRIPTION. The default is None.

        """
        # inherit
        super().__init__(toolkit=toolkit, figure=figure)
        # define axes
        self.raxis = cp(raxis)
