# -*- coding: utf-8 -*-
"""
Created on Sat Jan 13 07:38:13 2024

@author: bjorn
"""


# Python imports
import numpy as np


# ttwean imports
import src.ttwean as tt

def test_incidence_angle():
    angle = tt.input_to_angle(angle=123.)
    assert angle.grad == 123.

def test_incidence_angles():
    angle = tt.input_to_angles(start=10, end=20, nos=2)
    assert np.all(angle.grad == [[10.], [20.]])

test_incidence_angle()
test_incidence_angles()
