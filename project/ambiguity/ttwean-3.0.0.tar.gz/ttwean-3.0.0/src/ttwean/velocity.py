# -*- coding: utf-8 -*-
"""
Created on Mon Jan 15 08:09:10 2024

@author: bjorn
""""""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-01-28
"""


class Magnitude():
    """
    Characterize a velocity.

    """
    # pylint:disable=too-few-public-methods

    def __init__(self):
        """
        Initialize a velocity.

        Returns
        -------
        self :
            abs : absolute magnitude
            xxx : horizontal component
            zzz : vertical component
        """
        # init
        self.abs = None    # absolute magnitude
        self.xxx = None    # horizontal component
        self.zzz = None    # vertical component


class Velocity():
    """
    Characterize a velocity.

    """
    # pylint:disable=too-few-public-methods

    # initialize
    def __init__(self):
        """
        Initialize a velocity.

        """
        # inherit
        super().__init__()
        # init
        self.sign = None          # wavetype
        self.qqq = None           # shortcuts
        self.mag = Magnitude()    # magnitude / comp. of velocity
        self.dmag = Magnitude()   # magnitude / comp. of differential velocity
        self.vp0 = None           # reference P-velocity
        self.vs0 = None           # reference S-velocity
        self.grad = None          # incidence angle in grad
        self.rad = None           # incidence angle in rad
        self.nos = None           # sample number
        self.ggg = 0.

    def plotter(self, plot=False, label=None):
        """
        Plot phase-velocity.

        Parameters
        ----------
        plot : char
            plot commands
        label : char
            label, overwrites plot.label

        Returns
        -------
        self : VoigtPhaseVelocity

        """
        # graph point
        plot.radius = self.mag.abs.flatten()
        plot.direction = self.grad.flatten()
        # graph label
        if label is not None:
            plot.label = label
        # forward
        plot.polar()
        # return
        return self
