# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-01-28
"""


# ttinit   initialize energy-velocity parameters for each medium, wavetype, or
#          stretch
# ttvel    compute the energy velocity for each cell and time step

# Python imports
import numpy as np   # numpy


class TTWean():
    """
    Characterize energy velocity for simulation with ttcpry.

    """

    # initialize
    def __init__(self):
        pass

    # set the energy-velocity parameters
    @staticmethod
    def ttinit(
            vp0:float=None, vs0:float=None, delta:float=None, epsilon:float=None,
            wavetype:str=None, ggg:float=None) -> np.array:
        """
        Precompute the linear energy-velocity parameters once.

        ttinit must be run for each medium, wavetype, and/or stretch once. It is
        the user's responsibility to assign the correct output to each cell. See
        Giroux's Jupyter notebook for details.
        ttvel must be run for each incidence angle, and it would be valid, albeit
        impractical, for all cells of the same medium and for the same wavetype
        and stretch. Typically, though, it would be run for each cell for each time
        step.

        Typically,
            vp0[medium,stretch], vs0[medium,stretch],
            sss[medium,stretch,wavetype] = (
                ttinit(
                    vp0=VP0, vs0=VS0, delta=DELTA, epsilon=EPSILON,
                    wavetype="P" or wavetype="SV", ggg=GGG))
            vel[wavetype,angle,cell] = (
                ttvel(
                    vp0=vp0[medium,stretch], vs0=vs0[medium,stretch],
                    sss=sss[medium,stretch], wavetype=wavetype, angle=ANGLE)
        Note, all capital for user-defined parameters.
        Any stretch modifies P and SV-velocities: so, be careful not to overwrite
        your in- and output variable.
        Use the same wavetype for ttinit and ttray.

        Parameters
        ----------
        vp0 : float
            reference P-velocity
        vs0 : float
            reference S-velocity
        delta : float, default is 0.
            Thomsen parameter delta
        epsilon : float, default is 0.
            Thomsen parameter epsilon
        wavetype : char
            "P" : P-wave
            "SV" : S-wave
        ggg : float, default is 0. (neutral)
            stretch factor

        Returns
        -------
        vp0, vs0 : float
            P- and SV-reference velocities: modified only if stretched
        sss : np.array ([5x1])
            linear energy-velocity parameters

        """
        # pylint:disable=too-many-arguments
        # shortcuts for computing squared phase-velocity parameters
        vps2 = (vp0 / vs0) ** 2
        fac = 1. + 2. * vps2 / (vps2 - 1.) * delta
        # define squared phase-velocity parameters
        rrr =  np.full((5,1), fill_value=np.NAN, dtype=float)
        rrr[0,0] = 1.
        # compute squared phase-velocity parameters for a qP-wave
        if wavetype == "P":
            rrr[2,0] = 2. * delta
            rrr[4,0] = 2. * (epsilon - delta) * fac
        # compute squared phase-velocity parameters for a qSV-wave
        if wavetype == "SV":
            rrr[2,0] = 2. * vps2 * (epsilon - delta)
            rrr[4,0] = -1. * rrr[2,0] * fac
        # stretch
        if ggg != 0.:
            # stretch reference velocity
            vp0 *= np.sqrt(1. + ggg)
            vs0 *= np.sqrt(1. + ggg)
            # stretch squared phase-velocity parameters
            rrr[2,0] = (rrr[2,0] - ggg) / (1. + ggg)
            rrr[4,0] = rrr[4,0] / ((1. + ggg) ** 2)
        # compute squared energy-velocity parameters
        ttt =  np.full((5,1), fill_value=np.NAN, dtype=float)
        ttt[0,0] = 1.
        ttt[2,0] = rrr[2,0] / (1. + rrr[2,0])
        ttt[4,0] = (
            (rrr[2,0] ** 2 * (1. + rrr[2,0]) ** 2 + rrr[4,0])
            /
            (1. + rrr[2,0]) ** 4)
        # compute linear energy velocity parameters
        sss =  np.full((5,1), fill_value=np.NAN, dtype=float)
        sss[0,0] = 1.
        sss[2,0] = ttt[2,0] / 2.
        sss[4,0] = -1. * ttt[2,0] ** 2 / 8. + ttt[4,0] / 2.
        # return
        return vp0, vs0, sss

    # compute energy velocity
    @staticmethod
    def ttvel(
            vp0:float=None, vs0:float=None, sss:np.array=None, wavetype:str=None,
            angle:float=None) -> float:
        """
        Compute a linear energy velocity for a given directional angle.

        ttinit must be run for each medium, wavetype, and/or stretch once. It is
        the user's responsibility to assign the correct output to each cell. See
        Giroux's Jupyter notebook for details.
        ttvel must be run for each incidence angle, and it would be valid, albeit
        impractical, for all cells of the same medium and for the same wavetype
        and stretch. Typically, though, it would be run for each cell for each time
        step.

        Typically,
            vp0[medium,stretch], vs0[medium,stretch],
            sss[medium,stretch,wavetype] = (
                ttinit(
                    vp0=VP0, vs0=VS0, delta=DELTA, epsilon=EPSILON,
                    wavetype="P" or wavetype="SV", ggg=GGG))
            vel[wavetype,angle,cell] = (
                ttvel(
                    vp0=vp0[medium,stretch], vs0=vs0[medium,stretch],
                    sss=sss[medium,stretch], wavetype=wavetype, angle=ANGLE)
        Note, all capital for user-defined parameters.
        Any stretch modifies P and SV-velocities: so, be careful not to overwrite
        your in- and output variable.
        Use the same wavetype for ttinit and ttray.

        Parameters
        ----------
        vp0 : float
            reference P-velocity
        vs0 : float
            reference S-velocity
        sss : np.array ([5x1])
            linear energy-velocity parameters
        wavetype : char
            "P" : P-wave
            "SV" : S-wave
        angle : float
            incidence angle in radiant

        Returns
        -------
        vel : float
            magnitude of an energy velocity for the given incidence angle/wavetype

        """
        # trig values for phase angles
        sin = np.sin(angle)
        sin2 = sin * sin
        # shortcuts
        sss2 = sss[2,0]
        sss4 = sss[4,0]
        # velocity
        vel = (
            {"P": vp0, "SV": vs0}[wavetype]       # reference velocity
            *                                     # *
            (1. + (sss2 + sss4 * sin2) * sin2))   # (angle-dependent variation)
        # return
        return vel   # that's the magnitude
