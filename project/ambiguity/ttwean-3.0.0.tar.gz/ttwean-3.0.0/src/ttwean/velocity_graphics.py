# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
from matplotlib import pyplot as plt   # pyplot
import numpy as np                     # numpy


# ttwean imports
from .graphics import PolarGraphics


class VelocityGraphics(PolarGraphics):
    """
    Generate a polar figure of velocities.

    """

    def __init__(
            self, toolkit=None, figure=None, raxis=None):
        """
        Initialize a polar figure of velocities

        Parameters
        ----------
        toolkit : char
            GUI toolkit
                'qt' for use with iPython
                'notebook' for use with Jupyter Notebook
        figure : Figure
            num : int
                figure identifier (found in window header)
            title : char
                title
            figsize : tupel
                figure size
        raxis : Axis
            velocity axis
                min : float
                    minimum value
                max : float
                    maximum value
                step : float
                    tick step size
                xlabel : str
                    axis label
                ylabel : str
                    axis label

        """
        # pylint:disable=too-many-arguments
        # inherit
        super().__init__(toolkit=toolkit, figure=figure, raxis=raxis)
        # set velocity specifics
        self.radius = None
        self.direction = None

    def input_to_graphics(self, label=None):
        """
        Input line-specific information as, e.g., a line label.

        Parameters
        ----------
        title : char
            title
        label : char
            graph label

        """
        # label
        if label is not None:
            self.label = label
        # return
        return self

    def polar(self):
        """
        Plot a property over its angle.

        Recall to set plot.radius, direction and label beforehand.

        Parameters
        ----------
        self :
            num : char
                figure identifier
            radius : np.array
                value
            direction : np.array
                angle
            label : char
                label of graph

        """
        # set figure
        plt.figure(self.figure.num)
        # fonts
        self.set_font()
        # plot
        xxx = self.radius * np.sin(np.deg2rad(self.direction))
        yyy = self.radius * np.cos(np.deg2rad(self.direction))
        plt.plot(xxx, yyy, label=self.label)
        # label
        if self.label is not None:
            self.axx.legend()
        # return
        return self

    def polarfinal(self):
        """
        Close a velocity plot.

        Parameters
        ----------
        self :
            xmax : float
                max value either horizontal or vertical
            title : float
                title of figure
            xlabel, ylabel : float, default to vx, vz
                horizontal and vertical axes label


        """
        # limits
        plt.ylim(bottom=0, top=self.raxis.amax)
        plt.xlim(left=0, right=self.raxis.amax)
        # ticks
        ticks = [
            500. * iii
            for iii in range(int(np.round(self.raxis.amax / 500.)) + 1)]
        plt.yticks(ticks=ticks)
        plt.xticks(ticks=ticks)
        # square plot
        self.axx.set_aspect('equal', adjustable='box')
        # title, labels
        plt.title(self.figure.title)
        plt.xlabel("$v_x$")
        plt.ylabel("$v_z$")
        # return
        return self

    def close(self):
        """
        Close a graphic.

        Parameters
        ----------
        self :
            num : char
                figure identifier

        """
        # switch figure
        plt.figure(self.figure.num)
        # set lim, ticks
        self.polarfinal()
        # fonts
        self.set_font()
        # show
        # ### plt.draw()
        plt.show(block=self.figure.block)
