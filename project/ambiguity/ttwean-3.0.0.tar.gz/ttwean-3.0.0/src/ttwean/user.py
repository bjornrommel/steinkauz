# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""

# print options
ANGLEPRINT = True              # print incidence angle
ELASTICITYPRINT = True         # print elasticity
THOMSENPRINT = True            # print Thomsen anisotropy parameter
PARA1PRINT = True              # print phase-velocity parameter
PARA2PRINT = True              # print energy-velocity parameter
VOIGTPHASEPRINT = True         # print phase velocity from elasticity
THOMSENPHASEPRINT = True       # print phase velocity from Thomsen
APPROXPHASEPRINT = True        # print linear phase velocity
ENERGYPRINT = True             # print energy velocity and angle
APPROXENERGYPRINT = True       # print linear energy velocity
TRAVELPRINT = True             # print traveltime-offset


# incidence angle of the phase
START = 0.    # first incidence angle (float)
NOS = 91.    # increment of incidence angles (int)
END = 90.     # last incidence angle (float)
ANGLE = 30.   # single incidence angle (float) for use with ttcrpy


# graphics
TOOLKIT = 'qt'         # for use with iPython
# !!! TOOLKIT = 'notebook'   # for use with Jupyter Notebook
BLOCK = False          # True / False if figure shall be blocked or not

# graphics size
PUBLICWIDTH = 4. + 1./3.   # big figure width of an SEG article in inch
PUBLICHEIGHT = 6.          # figure height in inch
FIGSIZE = (PUBLICWIDTH, PUBLICHEIGHT)


# define "Dog Creek Shale" (Thomsen, 1986)
# (any example will do, but need some pre-defined input)
TITLE = "Dog Creek Shale"   # title
VP0 = 1875.                 # reference P-velocity
VS0 = 826.                  # reference S-Velocity
DELTA = 0.100               # Thomsen's delta
EPSILON = 0.225             # Thomsen's epsilon
GAMMA = 0.345               # Thomsen's gamma
RHO = 2000.                 # density
GGG = 0.201216              # stretch parameter
GGG = 2 * DELTA             # stretch parameter to near isotropy
# ### GGG = 0.                    # neutral stretch parameter


# geometry for traveltime-offset
DEPTH = 500    # interface depth
OFFSET = 500   # max receiver offset
DXX = 1        # receiver spacing
