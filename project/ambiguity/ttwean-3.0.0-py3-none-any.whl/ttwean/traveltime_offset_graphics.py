# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# Python imports
import sys                             # system
from matplotlib import pyplot as plt   # pyplot
import numpy as np                     # numpy


# ttwean imports
from .graphics import CartesianGraphics


class TraveltimeOffsetGraphics(CartesianGraphics):
    """
    Generate a traveltime-offset figure.

    """

    def __init__(self, toolkit=None, figure=None, xaxis=None, yaxis=None):
        """
        Set up the graphics figure.

        Maximum offset and traveltime are set globally for all traveltime-
        offset curves.

        Parameters
        ----------
        toolkit : char
            GUI toolkit
                'qt' for use with iPython
                'notebook' for use with Jupyter Notebook
        figure : Figure
            num : int
                figure identifier (found in window header)
            title : char
                title
            figsize : tupel
                figure size
        xaxis, yaxis : Axis
            offset, traveltime axes
                min : float
                    minimum value
                max : float
                    maximum value
                step : float
                    tick step size
                label : str
                    axis label

        Returns
        -------
        self : Graphic
            fig : plt.figure
                figure identifier
            axes : plt.figure.add_subplot
                subfigure identifier

        """
        # inherit
        super().__init__(
            toolkit=toolkit, figure=figure, xaxis=xaxis, yaxis=yaxis)
        # fonts
        self.set_font()      # set SEG fonts
        # label
        self.label = None    # graph label

    def input_to_graphics(self, label=None):
        """
        Input line-specific information as, e.g., a line label.

        Parameters
        ----------
        label : str
            line label

        """
        # label
        self.label = label
        # return
        return self

    def cartesian(self, xxx=None, yyy=None):
        """
        Plot a point in a cartesian coordinate system.

        Parameters
        ----------
        xxx : np.array ([number x 1]) of floats
            horizontal property to plot
        yyy : np.array ([number x 1]) of floats
            vertical property to plot

        Attributes
        ----------
        label : str
            graph label
            The graph label has been set beforehand by the user.

        """
        # figure
        plt.figure(self.figure.num)
        # plot graph in (x,y)-coordinates and annotate with label
        plt.plot(xxx, yyy, label=self.label)
        self.set_font()
        # label
        if self.label is not None:
            self.axx.legend()
            self.set_font()
        # return
        return self

    def close(self, *args):
        """
        Close a graphic.

        args shall be completed with all traveltime-offset curves being
        plotted. It allows to calculate the minimum and maximum of all axes
        limits of all traveltime-offset curves.

        """
        # switch figure
        plt.figure(self.figure.num)
        # compute offset, traveltime limits from data
        xmin = ymin = sys.float_info.max
        xmax = ymax = 0.
        for arg in args:
            xmin = min([xmin, np.amin(arg.xxx)])
            xmax = max([xmax, np.amax(arg.xxx)])
            ymin = min([ymin, np.amin(arg.yyy)])
            ymax = max([ymax, np.amax(arg.yyy)])
        # prioritize user-defined limits over above limits
        self.xaxis.amin = (
            self.xaxis.amin
            if (self.xaxis.amin is not None)
            else xmin)
        self.xaxis.amax = (
            self.xaxis.amax
            if (self.xaxis.amax is not None)
            else xmax)
        self.yaxis.amin = (
            self.yaxis.amin
            if (self.yaxis.amin is not None)
            else ymin)
        self.yaxis.amax = (
            self.yaxis.amax
            if (self.yaxis.amax is not None)
            else ymax)
        # set time axes
        plt.tick_params(
            axis='y', which='both', labelleft=True, labelright=True)
        # get leading time digit
        mag = 10 ** (np.floor(np.log10(np.abs(self.yaxis.amax))))
        # fix top and bottom of time axis
        ybot = np.floor(self.yaxis.amin / (mag / 10.)) * (mag / 10.)
        ytop = np.ceil(self.yaxis.amax / (mag / 10.)) * (mag / 10.)
        # fix time increments
        if self.yaxis.step is None:
            self.yaxis.step = (ytop - ybot) / 5.
            self.yaxis.step = max(self.yaxis.step, mag / 5.)
        ticks = [ybot + self.yaxis.step * iii for iii in range(1234)]
        ticks = [yyy for yyy in ticks if yyy <= self.yaxis.amax]
        # set limits
        plt.ylim(bottom=ybot, top=ytop)
        plt.yticks(ticks=ticks)
        # get leading offset digit
        mag = 10 ** (np.floor(np.log10(self.xaxis.amax)))
        # fix left and right offset axes
        xlet = np.floor(self.xaxis.amin / (mag / 10.)) * (mag / 10.)
        xrit = np.ceil(self.xaxis.amax / (mag / 10.)) * (mag / 10.)
        # fix offset increments
        if self.xaxis.step is None:
            self.xaxis.step = (xrit - xlet) / 5.
            self.xaxis.step = max(self.xaxis.step, mag / 5.)
        ticks = [xlet + self.xaxis.step * iii for iii in range(1234)]
        ticks = [xxx for xxx in ticks if xxx <= self.xaxis.amax]
        # set limits
        plt.xlim(left=xlet, right=xrit)
        plt.xticks(ticks=ticks)
        # title, labels
        plt.title(self.figure.title)
        plt.xlabel("Offset [m]")
        plt.ylabel("TravelOffset [s]")
        # fonts
        self.set_font()
        # show
        # ### plt.draw()
        plt.show(block=self.figure.block)
