# -*- coding: utf-8 -*-
"""
ttwean: Velocity-versus-Structure for Reflection Seismics!

ttwean is a collection of function used to investigate "stretch", a method to
generate a series of velocity-structure models all of which (approximately)
satisfy the same traveltime curve.

This program was written for use with ttcpry, software for ray-tracing
simulation https://ttcrpy.readthedocs.io/en/latest/ of wavefield propagation,
by Berard Giroux https://inrs.ca/en/research/professors/bernard-giroux/
His software repository is https://github.com/groupeLIAMG/ttcr

My software repository is https://github.com/bjornrommel/steinkauz under the
project Subsurface-Velocity Ambiguity.

@author: Björn E. Rommel
@email: ttwean@seisrock.com
@version: 3.0.0
@date: 2024-02-02
"""


# --- do not change below --- do not change below --- do not change below -----


# Computing the P- and SV-velocities, respectively, differs only by a sign, and
# therefore many formulae can be recycled for one another.

# wavetype
PSIGN = +1                                     # +1 for a P wave
SSIGN = -1                                     # -1 for an SV-wave
SIGN = {'P': PSIGN, 'SV': SSIGN, 'S': SSIGN}   # identifier to character
WVT = {SSIGN: 'SV', PSIGN: 'P'}                # character to identifier
